const Notification = require("../models/Notification");
const Repo = require("../utils/repo");

const notifications = new Repo(Notification);

exports.list = async (req, res) => {
  const list = await notifications.find({ userId: req.user.id }, { sort: { createdAt: -1 } });
  res.json(list);
};

exports.markRead = async (req, res) => {
  const updated = await notifications.updateById(req.params.id, { read: true });
  if (!updated) return res.status(404).json({ error: "Notification not found." });
  res.json(updated);
};

exports.unreadCount = async (req, res) => {
  const count = await notifications.count({ userId: req.user.id, read: false });
  res.json({ count });
};

// Internal helper used by other controllers to create a notification.
exports.notify = async (userId, type, message, relatedId = null) => {
  return notifications.create({ userId, type, message, relatedId, read: false });
};
