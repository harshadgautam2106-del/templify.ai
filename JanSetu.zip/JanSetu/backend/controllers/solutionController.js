const Solution = require("../models/Solution");
const Problem = require("../models/Problem");
const User = require("../models/User");
const Repo = require("../utils/repo");
const { POINTS, badgesForPoints } = require("../utils/helpers");
const { notify } = require("./notificationController");

const solutions = new Repo(Solution);
const problems = new Repo(Problem);
const users = new Repo(User);

exports.propose = async (req, res) => {
  const { problemId, title, description, estimatedCost, estimatedTime, requiredResources } = req.body;
  if (!problemId || !title || !description) return res.status(400).json({ error: "problemId, title, and description are required." });

  const problem = await problems.findById(problemId);
  if (!problem) return res.status(404).json({ error: "Problem not found." });

  const solution = await solutions.create({
    problemId, title, description, proposedBy: req.user.id,
    organizationId: req.body.organizationId || null,
    estimatedCost: estimatedCost ? Number(estimatedCost) : 0,
    estimatedTime: estimatedTime || "", requiredResources: requiredResources || "",
    votes: 0, voters: [], status: "Proposed",
  });

  await problems.updateById(problemId, {
    status: "Solution Proposed",
    statusHistory: [...(problem.statusHistory || []), { status: "Solution Proposed", note: `Solution "${title}" proposed.`, date: new Date().toISOString() }],
  });
  await awardPoints(req.user.id, POINTS.PROPOSE_SOLUTION);
  await notify(problem.reporterId, "new_solution", `A new solution was proposed for "${problem.title}".`, problemId);

  res.status(201).json(solution);
};

exports.listByProblem = async (req, res) => {
  const list = await solutions.find({ problemId: req.params.problemId }, { sort: { votes: -1 } });
  const enriched = await Promise.all(list.map(async (s) => {
    const proposer = await users.findById(s.proposedBy);
    return { ...s, proposedByName: proposer?.fullName || "Unknown" };
  }));
  res.json(enriched.sort((a, b) => (b.votes || 0) - (a.votes || 0)));
};

exports.listAll = async (req, res) => {
  const { mine, status } = req.query;
  const filter = {};
  if (mine === "true") filter.proposedBy = req.user.id;
  if (status) filter.status = status;
  const list = await solutions.find(filter, { sort: { createdAt: -1 } });
  const enriched = await Promise.all(list.map(async (s) => {
    const proposer = await users.findById(s.proposedBy);
    const problem = await problems.findById(s.problemId);
    return { ...s, proposedByName: proposer?.fullName || "Unknown", problemTitle: problem?.title || "Unknown problem" };
  }));
  res.json(enriched);
};

exports.vote = async (req, res) => {
  const solution = await solutions.findById(req.params.id);
  if (!solution) return res.status(404).json({ error: "Solution not found." });
  const voters = solution.voters || [];
  if (voters.includes(req.user.id)) return res.status(409).json({ error: "You've already voted for this solution." });

  const updated = await solutions.updateById(req.params.id, { voters: [...voters, req.user.id], votes: (solution.votes || 0) + 1 });
  res.json(updated);
};

exports.updateStatus = async (req, res) => {
  const { status } = req.body;
  const valid = ["Proposed", "Under Review", "Accepted", "In Progress", "Completed", "Rejected"];
  if (!valid.includes(status)) return res.status(400).json({ error: "Invalid status." });

  const solution = await solutions.findById(req.params.id);
  if (!solution) return res.status(404).json({ error: "Solution not found." });

  const updated = await solutions.updateById(req.params.id, { status });

  if (status === "Accepted") {
    await awardPoints(solution.proposedBy, POINTS.SOLUTION_ACCEPTED);
    const problem = await problems.findById(solution.problemId);
    if (problem) {
      await problems.updateById(solution.problemId, {
        status: "In Progress",
        statusHistory: [...(problem.statusHistory || []), { status: "In Progress", note: `Solution "${solution.title}" accepted.`, date: new Date().toISOString() }],
      });
    }
    await notify(solution.proposedBy, "solution_accepted", `Your solution "${solution.title}" was accepted!`, solution.problemId);
  }
  res.json(updated);
};

async function awardPoints(userId, amount) {
  const user = await users.findById(userId);
  if (!user) return;
  const points = (user.points || 0) + amount;
  await users.updateById(userId, { points, badges: badgesForPoints(points) });
}
