const User = require("../models/User");
const Organization = require("../models/Organization");
const Problem = require("../models/Problem");
const Solution = require("../models/Solution");
const Repo = require("../utils/repo");

const users = new Repo(User);
const organizations = new Repo(Organization);
const problems = new Repo(Problem);
const solutions = new Repo(Solution);

exports.getProfile = async (req, res) => {
  const id = req.params.id || req.user.id;
  const user = await users.findById(id);
  if (!user) return res.status(404).json({ error: "User not found." });

  const [reported, proposed] = await Promise.all([
    problems.find({ reporterId: id }),
    solutions.find({ proposedBy: id }),
  ]);
  const supportedCount = (await problems.find({})).filter((p) => (p.supporters || []).includes(id)).length;

  const { passwordHash, ...publicUser } = user;
  res.json({ ...publicUser, stats: { problemsReported: reported.length, solutionsProposed: proposed.length, problemsSupported: supportedCount } });
};

exports.updateProfile = async (req, res) => {
  const { fullName, location, bio, skills } = req.body;
  const updated = await users.updateById(req.user.id, {
    ...(fullName && { fullName }), ...(location !== undefined && { location }),
    ...(bio !== undefined && { bio }), ...(skills && { skills: Array.isArray(skills) ? skills : skills.split(",").map((s) => s.trim()) }),
  });
  const { passwordHash, ...publicUser } = updated;
  res.json(publicUser);
};

exports.listOrganizations = async (req, res) => {
  const { type } = req.query;
  const list = await organizations.find(type ? { type } : {});
  res.json(list);
};

exports.getOrganization = async (req, res) => {
  const org = await organizations.findById(req.params.id);
  if (!org) return res.status(404).json({ error: "Organization not found." });
  res.json(org);
};

exports.createOrUpdateOrganization = async (req, res) => {
  const { name, type, location, description, expertise, contactEmail } = req.body;
  if (!name || !type) return res.status(400).json({ error: "Organization name and type are required." });

  const existing = await organizations.findOne({ ownerId: req.user.id });
  const data = { ownerId: req.user.id, name, type, location: location || "", description: description || "", expertise: expertise ? expertise.split(",").map((e) => e.trim()) : [], contactEmail: contactEmail || "" };

  const org = existing ? await organizations.updateById(existing._id, data) : await organizations.create({ ...data, projects: [] });
  res.status(existing ? 200 : 201).json(org);
};

exports.adoptProblem = async (req, res) => {
  const org = await organizations.findOne({ ownerId: req.user.id });
  if (!org) return res.status(404).json({ error: "You don't have an organization profile yet." });
  const projects = [...new Set([...(org.projects || []), req.params.problemId])];
  const updated = await organizations.updateById(org._id, { projects });
  await problems.updateById(req.params.problemId, { organizationId: org._id, status: "Assigned" });
  res.json(updated);
};
