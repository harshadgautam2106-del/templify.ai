const User = require("../models/User");
const Repo = require("../utils/repo");
const { hashPassword, comparePassword, signToken } = require("../utils/helpers");

const users = new Repo(User);

exports.register = async (req, res) => {
  const { fullName, email, phone, password, confirmPassword, location, userType } = req.body;

  if (!fullName || !email || !password || !userType) {
    return res.status(400).json({ error: "Full name, email, password, and user type are required." });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters." });
  }
  if (confirmPassword !== undefined && password !== confirmPassword) {
    return res.status(400).json({ error: "Passwords do not match." });
  }

  const existing = await users.findOne({ email: email.toLowerCase() });
  if (existing) return res.status(409).json({ error: "Email already exists." });

  const passwordHash = await hashPassword(password);
  const user = await users.create({ fullName, email: email.toLowerCase(), phone, passwordHash, location, userType, points: 0, badges: [], skills: [], bio: "" });

  const token = signToken(user);
  res.status(201).json({ token, user: publicUser(user) });
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: "Email and password are required." });

  const user = await users.findOne({ email: email.toLowerCase() });
  if (!user) return res.status(401).json({ error: "Invalid email or password." });

  const valid = await comparePassword(password, user.passwordHash);
  if (!valid) return res.status(401).json({ error: "Invalid email or password." });

  const token = signToken(user);
  res.json({ token, user: publicUser(user) });
};

exports.logout = async (_req, res) => {
  // JWTs are stateless — logout is handled client-side by discarding the token.
  res.json({ ok: true });
};

exports.me = async (req, res) => {
  const user = await users.findById(req.user.id);
  if (!user) return res.status(404).json({ error: "User not found." });
  res.json(publicUser(user));
};

function publicUser(user) {
  const { passwordHash, ...rest } = user;
  return rest;
}
