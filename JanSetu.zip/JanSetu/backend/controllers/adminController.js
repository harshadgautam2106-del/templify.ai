const User = require("../models/User");
const Problem = require("../models/Problem");
const Solution = require("../models/Solution");
const Organization = require("../models/Organization");
const Repo = require("../utils/repo");

const users = new Repo(User);
const problems = new Repo(Problem);
const solutions = new Repo(Solution);
const organizations = new Repo(Organization);

exports.stats = async (_req, res) => {
  const [totalUsers, totalProblems, pending, resolved, activeProjects, totalOrgs] = await Promise.all([
    users.count({}),
    problems.count({}),
    problems.count({ status: "Submitted" }),
    problems.count({ status: "Resolved" }),
    problems.count({ status: "In Progress" }),
    organizations.count({}),
  ]);
  res.json({
    note: "Figures reflect this instance's current demo data.",
    totalUsers, totalProblems, pendingVerification: pending, activeProjects, resolvedProblems: resolved, totalOrganizations: totalOrgs,
  });
};

exports.listUsers = async (_req, res) => {
  const list = await users.find({});
  res.json(list.map(({ passwordHash, ...u }) => u));
};

exports.listPendingProblems = async (_req, res) => {
  const list = await problems.find({ status: "Submitted" });
  res.json(list);
};

exports.listAllProblems = async (_req, res) => {
  const list = await problems.find({}, { sort: { createdAt: -1 } });
  res.json(list);
};

exports.reviewSolutions = async (_req, res) => {
  const list = await solutions.find({ status: "Under Review" });
  res.json(list);
};
