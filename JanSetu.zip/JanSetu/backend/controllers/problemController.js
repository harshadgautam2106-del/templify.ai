const Problem = require("../models/Problem");
const Comment = require("../models/Comment");
const User = require("../models/User");
const Repo = require("../utils/repo");
const { POINTS, badgesForPoints, generateProblemCode } = require("../utils/helpers");
const { notify } = require("./notificationController");

const problems = new Repo(Problem);
const comments = new Repo(Comment);
const users = new Repo(User);

exports.create = async (req, res) => {
  const { title, description, category, subcategory, location, district, state, latitude, longitude, severity, tags } = req.body;
  if (!title || !description || !category) return res.status(400).json({ error: "Title, description, and category are required." });

  const count = await problems.count({});
  const images = (req.files || []).map((f) => `/uploads/${f.filename}`);
  const problemCode = generateProblemCode(count + 1);

  const problem = await problems.create({
    problemCode,
    title, description, category, subcategory: subcategory || "", location: location || "",
    district: district || "", state: state || "",
    latitude: latitude ? Number(latitude) : undefined, longitude: longitude ? Number(longitude) : undefined,
    severity: severity || "Medium", images, documents: [], tags: tags ? tags.split(",").map((t) => t.trim()) : [],
    reporterId: req.user.id, status: "Submitted", supporters: [],
    statusHistory: [{ status: "Submitted", note: "Problem reported by citizen.", date: new Date().toISOString() }],
  });
  res.status(201).json(problem);
};

exports.list = async (req, res) => {
  const { category, status, severity, district, sort, q } = req.query;
  const filter = {};
  if (category) filter.category = category;
  if (status) filter.status = status;
  if (severity) filter.severity = severity;
  if (district) filter.district = district;

  let sortOpt;
  if (sort === "supported") sortOpt = { supporters: -1 }; // approximate; mock store sorts by array length below
  else if (sort === "recent" || !sort) sortOpt = { createdAt: -1 };

  let list = await problems.find(filter, { sort: sortOpt });
  if (q) {
    const needle = q.toLowerCase();
    list = list.filter((p) =>
      p.title.toLowerCase().includes(needle) ||
      p.description.toLowerCase().includes(needle) ||
      (p.problemCode || "").toLowerCase().includes(needle)
    );
  }
  if (sort === "supported") list = list.sort((a, b) => (b.supporters?.length || 0) - (a.supporters?.length || 0));
  if (sort === "priority") {
    const weight = { Critical: 4, High: 3, Medium: 2, Low: 1 };
    list = list.sort((a, b) => (weight[b.severity] || 0) - (weight[a.severity] || 0));
  }

  res.json(list.map(withSupportCount));
};

// GET /api/problems/track/:code — exact lookup by the human-readable problem ID (e.g. JS-2026-00021)
exports.trackByCode = async (req, res) => {
  const code = req.params.code.trim().toUpperCase();
  const problem = await problems.findOne({ problemCode: code });
  if (!problem) return res.status(404).json({ error: `No problem found with ID "${req.params.code}".` });
  res.json(withSupportCount(problem));
};

exports.getById = async (req, res) => {
  const problem = await problems.findById(req.params.id);
  if (!problem) return res.status(404).json({ error: "Problem not found." });
  const reporter = await users.findById(problem.reporterId);
  const problemComments = await comments.find({ problemId: problem._id });
  res.json({ ...withSupportCount(problem), reporterName: reporter?.fullName || "Unknown", comments: problemComments });
};

exports.support = async (req, res) => {
  const problem = await problems.findById(req.params.id);
  if (!problem) return res.status(404).json({ error: "Problem not found." });
  const supporters = problem.supporters || [];
  if (supporters.includes(req.user.id)) return res.status(409).json({ error: "You've already supported this problem." });

  const updated = await problems.updateById(req.params.id, { supporters: [...supporters, req.user.id] });
  await awardPoints(req.user.id, POINTS.SUPPORT_PROBLEM);
  await notify(problem.reporterId, "problem_supported", `Someone supported your problem "${problem.title}".`, problem._id);
  res.json(withSupportCount(updated));
};

exports.addComment = async (req, res) => {
  const { text, parentCommentId } = req.body;
  if (!text) return res.status(400).json({ error: "Comment text is required." });
  const problem = await problems.findById(req.params.id);
  if (!problem) return res.status(404).json({ error: "Problem not found." });

  const comment = await comments.create({ problemId: req.params.id, userId: req.user.id, text, parentCommentId: parentCommentId || null, likes: 0, likedBy: [] });
  const author = await users.findById(req.user.id);
  if (problem.reporterId !== req.user.id) {
    await notify(problem.reporterId, "new_comment", `${author?.fullName || "Someone"} commented on your problem "${problem.title}".`, problem._id);
  }
  res.status(201).json({ ...comment, authorName: author?.fullName || "Unknown" });
};

exports.likeComment = async (req, res) => {
  const comment = await comments.findById(req.params.commentId);
  if (!comment) return res.status(404).json({ error: "Comment not found." });
  const likedBy = comment.likedBy || [];
  if (likedBy.includes(req.user.id)) return res.status(409).json({ error: "Already liked." });
  const updated = await comments.updateById(req.params.commentId, { likedBy: [...likedBy, req.user.id], likes: (comment.likes || 0) + 1 });
  res.json(updated);
};

// ---- Admin / organization actions on a problem's lifecycle ----
exports.updateStatus = async (req, res) => {
  const { status, note } = req.body;
  const valid = ["Submitted", "Under Review", "Verified", "Assigned", "Solution Proposed", "In Progress", "Resolved", "Closed", "Rejected"];
  if (!valid.includes(status)) return res.status(400).json({ error: "Invalid status." });

  const problem = await problems.findById(req.params.id);
  if (!problem) return res.status(404).json({ error: "Problem not found." });

  const statusHistory = [...(problem.statusHistory || []), { status, note: note || "", date: new Date().toISOString() }];
  const updated = await problems.updateById(req.params.id, { status, statusHistory });

  if (status === "Verified") await awardPoints(problem.reporterId, POINTS.REPORT_VERIFIED);
  await notify(problem.reporterId, "status_changed", `Your problem "${problem.title}" is now "${status}".`, problem._id);
  res.json(updated);
};

exports.assignOrganization = async (req, res) => {
  const { organizationId } = req.body;
  const updated = await problems.updateById(req.params.id, { organizationId, status: "Assigned" });
  res.json(updated);
};

function withSupportCount(problem) {
  return { ...problem, supportCount: problem.supporters?.length || 0 };
}

async function awardPoints(userId, amount) {
  const user = await users.findById(userId);
  if (!user) return;
  const points = (user.points || 0) + amount;
  await users.updateById(userId, { points, badges: badgesForPoints(points) });
}

exports._repos = { problems, comments, users }; // exported for reuse by adminController
