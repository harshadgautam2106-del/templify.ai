const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const SECRET = process.env.JWT_SECRET || "dev-secret";

async function hashPassword(password) {
  return bcrypt.hash(password, 10);
}

async function comparePassword(password, hash) {
  return bcrypt.compare(password, hash);
}

function signToken(user) {
  return jwt.sign({ id: user._id, userType: user.userType, email: user.email }, SECRET, { expiresIn: "7d" });
}

function verifyToken(token) {
  return jwt.verify(token, SECRET);
}

// Simple point + badge system (section 19 of the spec).
const POINTS = {
  REPORT_VERIFIED: 20,
  SUPPORT_PROBLEM: 2,
  PROPOSE_SOLUTION: 15,
  SOLUTION_ACCEPTED: 40,
};

function badgesForPoints(points) {
  const badges = [];
  if (points >= 20) badges.push("Problem Reporter");
  if (points >= 50) badges.push("Community Helper");
  if (points >= 100) badges.push("Solution Expert");
  return badges;
}

function generateProblemCode(sequence) {
  const year = new Date().getFullYear();
  return `JS-${year}-${String(sequence).padStart(5, "0")}`;
}

module.exports = { hashPassword, comparePassword, signToken, verifyToken, POINTS, badgesForPoints, generateProblemCode };
