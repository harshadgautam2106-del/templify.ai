require("dotenv").config();
const { connectDB } = require("../config/database");
const User = require("../models/User");
const Problem = require("../models/Problem");
const Solution = require("../models/Solution");
const Organization = require("../models/Organization");
const Repo = require("./repo");
const { hashPassword } = require("./helpers");

const users = new Repo(User);
const problems = new Repo(Problem);
const solutions = new Repo(Solution);
const organizations = new Repo(Organization);

const CATEGORIES = ["Education", "Healthcare", "Agriculture", "Water & Sanitation", "Infrastructure", "Environment", "Employment", "Public Safety", "Transportation", "Other"];
const SEVERITIES = ["Low", "Medium", "High", "Critical"];
const DISTRICTS = ["Bhopal", "Indore", "Sehore", "Vidisha", "Hoshangabad"];

async function main() {
  await connectDB();
  console.log("Seeding JanSetu demo data (all fictional)...");

  const pw = await hashPassword("password123");

  const citizen = await users.create({ fullName: "Anita Verma", email: "citizen@demo.com", phone: "9990000001", passwordHash: pw, location: "Bhopal", userType: "citizen", points: 0, badges: [], skills: [], bio: "" });
  const student = await users.create({ fullName: "Ravi Kumar", email: "student@demo.com", phone: "9990000002", passwordHash: pw, location: "Indore", userType: "student", points: 0, badges: [], skills: ["IoT", "Mobile Development"], bio: "Final year CS student." });
  const university = await users.create({ fullName: "MANIT Bhopal", email: "university@demo.com", phone: "9990000003", passwordHash: pw, location: "Bhopal", userType: "university", points: 0, badges: [], skills: [], bio: "" });
  const industry = await users.create({ fullName: "Fatima Sheikh", email: "industry@demo.com", phone: "9990000004", passwordHash: pw, location: "Indore", userType: "industry", points: 0, badges: [], skills: ["Water Management"], bio: "" });
  const ngo = await users.create({ fullName: "Green Earth NGO", email: "ngo@demo.com", phone: "9990000005", passwordHash: pw, location: "Sehore", userType: "ngo", points: 0, badges: [], skills: [], bio: "" });
  const expert = await users.create({ fullName: "Dr. Mehta", email: "expert@demo.com", phone: "9990000006", passwordHash: pw, location: "Bhopal", userType: "expert", points: 0, badges: [], skills: ["Public Health"], bio: "" });
  await users.create({ fullName: "District Admin", email: "admin@demo.com", phone: "9990000007", passwordHash: pw, location: "Bhopal", userType: "admin", points: 0, badges: [], skills: [], bio: "" });

  const extraCitizens = [];
  for (let i = 0; i < 6; i++) {
    extraCitizens.push(await users.create({ fullName: `Citizen ${i + 2}`, email: `citizen${i + 2}@demo.com`, passwordHash: pw, location: DISTRICTS[i % DISTRICTS.length], userType: "citizen", points: 0, badges: [], skills: [], bio: "" }));
  }

  await organizations.create({ ownerId: university._id, name: "MANIT Bhopal", type: "university", location: "Bhopal", description: "Leading technical university in Madhya Pradesh.", expertise: ["IoT", "Civil Engineering", "Computer Science"], projects: [], contactEmail: "outreach@manit.demo" });
  await organizations.create({ ownerId: industry._id, name: "ABC Technologies", type: "industry", location: "Indore", description: "Water and smart-infrastructure technology company.", expertise: ["IoT", "Water Management"], projects: [], contactEmail: "partnerships@abctech.demo" });
  await organizations.create({ ownerId: ngo._id, name: "Green Earth NGO", type: "ngo", location: "Sehore", description: "Community-driven environmental and sanitation NGO.", expertise: ["Sanitation", "Community Mobilization"], projects: [], contactEmail: "contact@greenearth.demo" });

  const titles = [
    "No streetlights on the main village road", "Drinking water supply irregular for two weeks", "Overflowing garbage bins near market",
    "Potholes causing accidents on the highway link road", "School lacks functional toilets for girls", "Health sub-centre has no doctor on weekdays",
    "Irrigation canal blocked with silt", "Public bus service cancelled without notice", "Open drain causing mosquito breeding",
    "Frequent power cuts affecting small businesses", "Illegal dumping near riverbank", "Mobile network dead zone in hamlet",
    "Farmers unable to get fair price for produce", "Public toilet locked most of the day", "Water tanker supply delayed repeatedly",
    "Broken hand pump in tribal colony", "River water contaminated by factory discharge", "Village library shut for six months",
    "Groundwater depletion in peri-urban wards", "Dropout tracking for first-generation learners",
  ];

  const allReporters = [citizen, ...extraCitizens];
  const createdProblems = [];
  for (let i = 0; i < titles.length; i++) {
    const category = CATEGORIES[i % CATEGORIES.length];
    const district = DISTRICTS[i % DISTRICTS.length];
    const severity = SEVERITIES[i % SEVERITIES.length];
    const status = i < 8 ? "Verified" : i < 12 ? "In Progress" : i < 14 ? "Resolved" : "Submitted";
    const reporter = allReporters[i % allReporters.length];
    const p = await problems.create({
      problemCode: `JS-2026-${String(i + 1).padStart(5, "0")}`,
      title: titles[i],
      description: `${titles[i]}. Reported in ${district} district; residents are asking for a prompt resolution.`,
      category, subcategory: "", location: district, district, state: "Madhya Pradesh",
      severity, images: [], documents: [], tags: [category.toLowerCase()],
      reporterId: reporter._id, status,
      supporters: allReporters.filter(() => Math.random() > 0.5).map((u) => u._id),
      statusHistory: [{ status, note: "Seeded demo problem.", date: new Date().toISOString() }],
    });
    createdProblems.push(p);
  }

  // Solutions on the first 5 verified/in-progress problems
  const targets = createdProblems.filter((p) => p.status === "Verified" || p.status === "In Progress").slice(0, 5);
  for (const p of targets) {
    await solutions.create({
      problemId: p._id, title: `Community-driven fix for: ${p.title}`, description: "A low-cost, locally maintainable intervention designed with resident input.",
      proposedBy: student._id, organizationId: null, estimatedCost: 15000 + Math.random() * 40000, estimatedTime: "8-12 weeks",
      requiredResources: "Basic hardware, volunteer labor, local panchayat coordination.", votes: Math.floor(Math.random() * 20), voters: [], status: "Proposed",
    });
  }

  console.log("Seed complete.");
  console.log("Demo accounts (password: password123): citizen@demo.com, student@demo.com, university@demo.com, industry@demo.com, ngo@demo.com, expert@demo.com, admin@demo.com");
  process.exit(0);
}

main().catch((e) => { console.error(e); process.exit(1); });
