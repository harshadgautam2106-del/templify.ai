const { isDbConnected } = require("../config/database");
const mockStore = require("./mockStore");

// Every controller talks to the database only through a Repo instance.
// That means controllers never know (or care) whether MongoDB is actually
// connected or we're on the in-memory dev fallback — same calls either way.
class Repo {
  constructor(mongooseModel) {
    this.Model = mongooseModel;
    this.name = mongooseModel.collectionName;
  }

  async create(data) {
    if (isDbConnected()) {
      const doc = await this.Model.create(data);
      return doc.toObject();
    }
    return mockStore.create(this.name, data);
  }

  async find(filter = {}, opts = {}) {
    if (isDbConnected()) {
      let q = this.Model.find(filter);
      if (opts.sort) q = q.sort(opts.sort);
      if (opts.limit) q = q.limit(opts.limit);
      return (await q.lean()).map((d) => ({ ...d, _id: String(d._id) }));
    }
    return mockStore.find(this.name, filter, opts);
  }

  async findOne(filter = {}) {
    if (isDbConnected()) {
      const doc = await this.Model.findOne(filter).lean();
      return doc ? { ...doc, _id: String(doc._id) } : null;
    }
    return mockStore.findOne(this.name, filter);
  }

  async findById(id) {
    if (isDbConnected()) {
      const doc = await this.Model.findById(id).lean();
      return doc ? { ...doc, _id: String(doc._id) } : null;
    }
    return mockStore.findById(this.name, id);
  }

  async updateById(id, patch) {
    if (isDbConnected()) {
      const doc = await this.Model.findByIdAndUpdate(id, patch, { new: true }).lean();
      return doc ? { ...doc, _id: String(doc._id) } : null;
    }
    return mockStore.updateById(this.name, id, patch);
  }

  async deleteById(id) {
    if (isDbConnected()) {
      await this.Model.findByIdAndDelete(id);
      return true;
    }
    return mockStore.deleteById(this.name, id);
  }

  async count(filter = {}) {
    if (isDbConnected()) return this.Model.countDocuments(filter);
    return mockStore.count(this.name, filter);
  }
}

module.exports = Repo;
