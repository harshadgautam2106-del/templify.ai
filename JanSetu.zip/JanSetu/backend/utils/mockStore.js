// Lightweight in-memory collection store used as the development fallback
// when MongoDB isn't reachable (see config/database.js). It mimics the
// small slice of Mongoose's query API that this app's repositories use, so
// the rest of the codebase (repositories, controllers) doesn't need to know
// which backend is actually serving requests. Collections are persisted to
// a JSON file on disk so data survives across separate process runs (e.g.
// `npm run seed` followed by `npm run dev`) without needing a real database.
const { randomUUID } = require("crypto");
const fs = require("fs");
const path = require("path");

const DATA_FILE = path.join(__dirname, "..", "mockdb.json");

const collections = {};

function loadFromDisk() {
  if (!fs.existsSync(DATA_FILE)) return;
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
    for (const [name, docs] of Object.entries(raw)) {
      collections[name] = new Map(docs.map((d) => [d._id, d]));
    }
  } catch (err) {
    console.warn("[JanSetu] Could not read mockdb.json, starting fresh:", err.message);
  }
}
loadFromDisk();

function saveToDisk() {
  const plain = {};
  for (const [name, map] of Object.entries(collections)) plain[name] = [...map.values()];
  fs.writeFileSync(DATA_FILE, JSON.stringify(plain, null, 2));
}

function collection(name) {
  if (!collections[name]) collections[name] = new Map();
  return collections[name];
}

function matches(doc, filter = {}) {
  return Object.entries(filter).every(([key, value]) => {
    if (value && typeof value === "object" && value.$in) return value.$in.includes(doc[key]);
    if (value && typeof value === "object" && value.$regex) return new RegExp(value.$regex, value.$options || "i").test(doc[key] || "");
    return doc[key] === value;
  });
}

const mockStore = {
  reset(name) {
    collections[name] = new Map();
    saveToDisk();
  },
  async create(name, data) {
    const id = data._id || randomUUID();
    const doc = { _id: id, createdAt: new Date().toISOString(), ...data };
    collection(name).set(id, doc);
    saveToDisk();
    return { ...doc };
  },
  async find(name, filter = {}, { sort, limit } = {}) {
    let docs = [...collection(name).values()].filter((d) => matches(d, filter));
    if (sort) {
      const [key, dir] = Object.entries(sort)[0];
      docs = docs.sort((a, b) => (dir === -1 ? (b[key] > a[key] ? 1 : -1) : a[key] > b[key] ? 1 : -1));
    }
    if (limit) docs = docs.slice(0, limit);
    return docs.map((d) => ({ ...d }));
  },
  async findOne(name, filter = {}) {
    const docs = await this.find(name, filter);
    return docs[0] || null;
  },
  async findById(name, id) {
    const doc = collection(name).get(id);
    return doc ? { ...doc } : null;
  },
  async updateById(name, id, patch) {
    const col = collection(name);
    const existing = col.get(id);
    if (!existing) return null;
    const updated = { ...existing, ...patch, updatedAt: new Date().toISOString() };
    col.set(id, updated);
    saveToDisk();
    return { ...updated };
  },
  async deleteById(name, id) {
    const result = collection(name).delete(id);
    saveToDisk();
    return result;
  },
  async count(name, filter = {}) {
    return (await this.find(name, filter)).length;
  },
};

module.exports = mockStore;
