const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  fullName: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true },
  phone: { type: String },
  passwordHash: { type: String, required: true },
  location: { type: String },
  userType: {
    type: String,
    enum: ["citizen", "student", "university", "industry", "ngo", "expert", "admin"],
    default: "citizen",
  },
  bio: { type: String, default: "" },
  skills: { type: [String], default: [] },
  points: { type: Number, default: 0 },
  badges: { type: [String], default: [] },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.User || mongoose.model("User", userSchema);
module.exports.collectionName = "users";
