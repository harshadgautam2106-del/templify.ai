const mongoose = require("mongoose");

const organizationSchema = new mongoose.Schema({
  ownerId: { type: String, required: true }, // the User account that manages this org profile
  name: { type: String, required: true },
  type: { type: String, enum: ["university", "industry", "ngo"], required: true },
  location: { type: String, default: "" },
  description: { type: String, default: "" },
  expertise: { type: [String], default: [] },
  projects: { type: [String], default: [] }, // problem IDs the org has adopted
  contactEmail: { type: String, default: "" },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.Organization || mongoose.model("Organization", organizationSchema);
module.exports.collectionName = "organizations";
