const mongoose = require("mongoose");

const statusHistorySchema = new mongoose.Schema(
  { status: String, note: String, date: { type: Date, default: Date.now } },
  { _id: false }
);

const problemSchema = new mongoose.Schema({
  problemCode: { type: String, unique: true, sparse: true },
  title: { type: String, required: true },
  description: { type: String, required: true },
  category: { type: String, required: true },
  subcategory: { type: String, default: "" },
  location: { type: String, default: "" },
  district: { type: String, default: "" },
  state: { type: String, default: "" },
  latitude: Number,
  longitude: Number,
  severity: { type: String, enum: ["Low", "Medium", "High", "Critical"], default: "Medium" },
  images: { type: [String], default: [] },
  documents: { type: [String], default: [] },
  tags: { type: [String], default: [] },
  reporterId: { type: String, required: true },
  status: {
    type: String,
    enum: ["Submitted", "Under Review", "Verified", "Assigned", "Solution Proposed", "In Progress", "Resolved", "Closed", "Rejected"],
    default: "Submitted",
  },
  statusHistory: { type: [statusHistorySchema], default: [] },
  organizationId: { type: String, default: null },
  supporters: { type: [String], default: [] },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.Problem || mongoose.model("Problem", problemSchema);
module.exports.collectionName = "problems";
