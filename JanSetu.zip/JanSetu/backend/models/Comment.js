const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema({
  problemId: { type: String, required: true },
  userId: { type: String, required: true },
  text: { type: String, required: true },
  parentCommentId: { type: String, default: null },
  likes: { type: Number, default: 0 },
  likedBy: { type: [String], default: [] },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.Comment || mongoose.model("Comment", commentSchema);
module.exports.collectionName = "comments";
