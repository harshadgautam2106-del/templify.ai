const mongoose = require("mongoose");

const solutionSchema = new mongoose.Schema({
  problemId: { type: String, required: true },
  title: { type: String, required: true },
  description: { type: String, required: true },
  proposedBy: { type: String, required: true },
  organizationId: { type: String, default: null },
  estimatedCost: { type: Number, default: 0 },
  estimatedTime: { type: String, default: "" },
  requiredResources: { type: String, default: "" },
  votes: { type: Number, default: 0 },
  voters: { type: [String], default: [] },
  status: {
    type: String,
    enum: ["Proposed", "Under Review", "Accepted", "In Progress", "Completed", "Rejected"],
    default: "Proposed",
  },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.Solution || mongoose.model("Solution", solutionSchema);
module.exports.collectionName = "solutions";
