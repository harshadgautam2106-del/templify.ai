const mongoose = require("mongoose");

// Tracks which backing store is active. Controllers/repositories check this
// flag (via isDbConnected()) to decide whether to talk to real Mongoose
// models or the in-memory fallback in utils/mockStore.js.
let connected = false;

async function connectDB() {
  const uri = process.env.MONGO_URI;
  if (!uri) {
    console.warn("[JanSetu] No MONGO_URI set — running on the in-memory mock database (dev fallback).");
    return false;
  }
  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 2500 });
    connected = true;
    console.log("[JanSetu] Connected to MongoDB.");
    return true;
  } catch (err) {
    console.warn(`[JanSetu] Could not connect to MongoDB (${err.message}). Falling back to the in-memory mock database.`);
    connected = false;
    return false;
  }
}

function isDbConnected() {
  return connected;
}

module.exports = { connectDB, isDbConnected };
