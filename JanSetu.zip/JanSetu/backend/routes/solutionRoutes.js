const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/solutionController");
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");

router.post("/", auth, role("student", "university", "industry", "ngo", "expert"), ctrl.propose);
router.get("/", auth, ctrl.listAll);
router.get("/problem/:problemId", auth, ctrl.listByProblem);
router.post("/:id/vote", auth, ctrl.vote);
router.patch("/:id/status", auth, role("admin", "university", "industry", "ngo"), ctrl.updateStatus);

module.exports = router;
