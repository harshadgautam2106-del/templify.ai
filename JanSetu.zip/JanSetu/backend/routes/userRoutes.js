const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/userController");
const auth = require("../middleware/authMiddleware");

router.get("/profile", auth, ctrl.getProfile);
router.get("/profile/:id", auth, ctrl.getProfile);
router.patch("/profile", auth, ctrl.updateProfile);
router.get("/organizations", auth, ctrl.listOrganizations);
router.get("/organizations/:id", auth, ctrl.getOrganization);
router.post("/organizations", auth, ctrl.createOrUpdateOrganization);
router.post("/organizations/adopt/:problemId", auth, ctrl.adoptProblem);

module.exports = router;
