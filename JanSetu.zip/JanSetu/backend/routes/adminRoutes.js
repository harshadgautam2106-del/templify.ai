const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/adminController");
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");

router.use(auth, role("admin"));
router.get("/stats", ctrl.stats);
router.get("/users", ctrl.listUsers);
router.get("/problems/pending", ctrl.listPendingProblems);
router.get("/problems", ctrl.listAllProblems);
router.get("/solutions/review", ctrl.reviewSolutions);

module.exports = router;
