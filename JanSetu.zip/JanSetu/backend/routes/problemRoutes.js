const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/problemController");
const auth = require("../middleware/authMiddleware");
const role = require("../middleware/roleMiddleware");
const upload = require("../utils/upload");

router.get("/", auth, ctrl.list);
router.get("/track/:code", auth, ctrl.trackByCode);
router.post("/", auth, upload.array("images", 5), ctrl.create);
router.get("/:id", auth, ctrl.getById);
router.post("/:id/support", auth, ctrl.support);
router.post("/:id/comments", auth, ctrl.addComment);
router.post("/comments/:commentId/like", auth, ctrl.likeComment);
router.patch("/:id/status", auth, role("admin", "university", "industry", "ngo"), ctrl.updateStatus);
router.patch("/:id/assign", auth, role("admin"), ctrl.assignOrganization);

module.exports = router;
