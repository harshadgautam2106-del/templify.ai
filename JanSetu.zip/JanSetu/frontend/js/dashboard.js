renderNav("dashboard");
Auth.requireLogin();
applyI18n();

const user = Auth.getUser();
document.getElementById("welcome").textContent = `${t("dash_welcome")}, ${user.fullName.split(" ")[0]}`;

async function loadDashboard() {
  try {
    const [allProblems, notifications] = await Promise.all([
      api.get("/problems"),
      api.get("/notifications"),
    ]);
    const mine = allProblems.filter((p) => p.reporterId === user._id);

    const counts = {
      reported: mine.length,
      review: mine.filter((p) => ["Submitted", "Under Review"].includes(p.status)).length,
      solving: mine.filter((p) => ["Assigned", "Solution Proposed", "In Progress"].includes(p.status)).length,
      resolved: mine.filter((p) => p.status === "Resolved").length,
    };

    document.getElementById("overview").innerHTML = `
      <div class="stat-card"><div class="stat-num" id="c1">0</div><div class="stat-label" data-i18n="dash_reported">Problems Reported</div></div>
      <div class="stat-card"><div class="stat-num" id="c2">0</div><div class="stat-label" data-i18n="dash_review">Under Review</div></div>
      <div class="stat-card"><div class="stat-num" id="c3">0</div><div class="stat-label" data-i18n="dash_solving">Being Solved</div></div>
      <div class="stat-card"><div class="stat-num" id="c4">0</div><div class="stat-label" data-i18n="dash_resolved">Resolved</div></div>
    `;
    applyI18n();
    animateNumber(document.getElementById("c1"), counts.reported);
    animateNumber(document.getElementById("c2"), counts.review);
    animateNumber(document.getElementById("c3"), counts.solving);
    animateNumber(document.getElementById("c4"), counts.resolved);

    const myProblemsEl = document.getElementById("my-problems");
    if (!mine.length) {
      myProblemsEl.innerHTML = `<div class="empty-state">${t("dash_no_problems")} <a href="submit-problem.html">${t("dash_report_first")}</a>.</div>`;
    } else {
      myProblemsEl.innerHTML = `<div class="problem-grid">` + mine.slice(0, 6).map((p) => `
        <a href="problem-details.html?id=${p._id}" class="card card-hover problem-card">
          <div class="problem-card-top">
            <h3>${escapeHtml(p.title)}</h3>
            <span class="pill ${severityClass(p.severity)}">${trSeverity(p.severity)}</span>
          </div>
          <div class="problem-meta">
            <span>🏷 ${trCategory(p.category)}</span>
            <span>📍 ${escapeHtml(p.district || "—")}</span>
            <span class="pill ${statusClass(p.status)}">${trStatus(p.status)}</span>
          </div>
          <div class="problem-footer"><span>👥 ${p.supportCount || 0}</span><span>${timeAgo(p.createdAt)}</span></div>
        </a>
      `).join("") + `</div>`;
    }

    const activityEl = document.getElementById("activity");
    if (!notifications.length) {
      activityEl.innerHTML = `<div class="empty-state">${t("dash_no_activity")}</div>`;
    } else {
      activityEl.innerHTML = notifications.slice(0, 8).map((n) => `
        <div class="comment-item">
          <div>${escapeHtml(n.message)}</div>
          <div style="font-size:11.5px;color:var(--muted);margin-top:2px;">${timeAgo(n.createdAt)}</div>
        </div>
      `).join("");
    }
  } catch (err) {
    showToast(err.message, "error");
  }
}

loadDashboard();
