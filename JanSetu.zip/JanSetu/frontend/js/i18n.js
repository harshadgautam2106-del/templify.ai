// i18n.js — shared across every page. Language choice persists in
// localStorage. Changing language triggers a full page reload so every
// page's own JS re-renders its dynamic content in the new language without
// each page needing custom re-render logic.

const I18N_DICTS = {
  en: {
    nav_home: "Home", nav_problems: "Problems", nav_solutions: "Solutions", nav_how: "How It Works",
    nav_login: "Login", nav_register: "Register", nav_dashboard: "Dashboard", nav_report: "Report",
    nav_profile: "Profile", nav_admin: "Admin", nav_logout: "Logout",

    hero_title: "Turn Local Problems Into Collaborative Solutions.",
    hero_badge: "🤝 Citizens + Students + Industry, Together",
    hero_desc: "Report the problems affecting your community. Universities, students, industry, and NGOs collaborate with you to design, propose, and implement real solutions — with every step tracked transparently.",
    hero_report: "Report a Problem", hero_explore: "Explore Problems",
    sync_live: "Synced", sync_offline: "Offline",
    compare_title: "Response time, before vs. after", compare_traditional: "Traditional process",
    compare_jansetu: "With JanSetu", compare_note: "Illustrative comparison, not measured platform data.", compare_jansetu_days: "6 days",
    stat_reported: "Problems Reported", stat_solved: "Problems Solved", stat_contributors: "Active Contributors", stat_orgs: "Organizations Participating",
    how_title: "How It Works", how_desc: "From a reported issue to a real-world fix.",
    step1_t: "Report", step1_d: "Citizens report a local problem with details, location, and evidence.",
    step2_t: "Verify", step2_d: "The community and administrators confirm and prioritize it.",
    step3_t: "Collaborate", step3_d: "Students, universities, and industry propose solutions.",
    step4_t: "Solve", step4_d: "The best solution is accepted and implemented.",
    step5_t: "Track Impact", step5_d: "Everyone can follow the problem through to resolution.",
    categories_title: "Browse by Category", featured_title: "Featured Problems",
    login_to_explore: "Log in to explore problems",
    track_title: "Track a Problem", track_placeholder: "Enter Problem ID (e.g. JS-2026-00021)", track_btn: "Track",
    track_not_found: "No problem found with that ID.",

    login_title: "Welcome back", login_subtitle: "Log in to continue collaborating on JanSetu.",
    email: "Email", password: "Password", remember_me: "Remember me", forgot_password: "Forgot password?",
    login_btn: "Login", new_here: "New here?", create_account: "Create an account",
    demo_accounts_note: "Demo accounts (password: password123): citizen@demo.com · student@demo.com · university@demo.com · industry@demo.com · ngo@demo.com · expert@demo.com · admin@demo.com",
    forgot_alert: "Password reset isn't wired up in this prototype yet — use one of the demo accounts below, or register a new one.",

    register_title: "Create your account", register_subtitle: "Join citizens, students, universities, industry, and NGOs solving problems together.",
    full_name: "Full Name", phone: "Phone", confirm_password: "Confirm Password", location: "Location", i_am_a: "I am a...",
    already_have_account: "Already have an account?", log_in: "Log in", create_account_btn: "Create account",

    role_citizen: "Citizen", role_student: "Student", role_university: "University", role_industry: "Industry", role_ngo: "NGO", role_expert: "Expert", role_admin: "Admin",

    dash_welcome: "Welcome back", dash_subtitle: "Here's what's happening with your contributions.",
    dash_report_btn: "Report Problem", dash_explore_btn: "Explore Problems", dash_contrib_btn: "My Contributions", dash_notif_btn: "Notifications",
    dash_my_problems: "My Problems", dash_activity: "Recent Activity",
    dash_no_problems: "You haven't reported any problems yet.", dash_report_first: "Report your first one",
    dash_no_activity: "No recent activity yet.",
    dash_reported: "Problems Reported", dash_review: "Under Review", dash_solving: "Being Solved", dash_resolved: "Resolved",

    explore_title: "Explore Problems", explore_subtitle: "Search, filter, and support the problems that matter to you.",
    search_placeholder: "Search problems…", all_categories: "All categories", all_severities: "All severities", all_statuses: "All statuses",
    sort_recent: "Most Recent", sort_supported: "Most Supported", sort_priority: "Highest Priority",
    no_problems_match: "No problems match these filters.", support_btn: "Support", supported_btn: "Supported",

    back_to_problems: "← Back to problems", propose_solution_btn: "💡 Propose a Solution", share_btn: "🔗 Share",
    you_reported: "You reported this problem", link_copied: "Link copied to clipboard.",
    status_timeline: "Status Timeline", proposed_solutions: "Proposed Solutions", discussion: "Discussion",
    add_comment_placeholder: "Add a comment…", post_btn: "Post", no_comments: "No comments yet — start the discussion.",
    snapshot_title: "Problem Snapshot", snapshot_status: "Status", snapshot_severity: "Severity", snapshot_supporters: "Supporters", snapshot_tags: "Tags",
    update_status_label: "Update Status (moderator)", update_btn: "Update", no_solutions_yet: "No solutions proposed yet.",
    accept_solution_btn: "Accept Solution", vote_btn: "votes",
    propose_form_title: "Propose a Solution", solution_title_label: "Solution Title", description_label: "Description",
    est_cost_label: "Estimated Cost (₹)", est_time_label: "Estimated Time", required_resources_label: "Required Resources",
    submit_proposal_btn: "Submit Proposal", solution_proposed_toast: "Solution proposed!", thanks_support: "Thanks for supporting this problem!",
    status_updated_toast: "Status updated.", solution_accepted_toast: "Solution accepted!",

    report_title: "Report a Local Problem", report_subtitle: "Describe the issue clearly — a citizen should be able to report a problem in under a minute.",
    title_label: "Problem Title", speak_hint: "Tap the mic to speak your problem instead of typing.",
    listening: "Listening…", demo_transcript_note: "Demo transcript inserted — edit as needed.",
    category_label: "Category", severity_label: "Severity", district_label: "District", state_label: "State",
    location_label: "Location", use_location_btn: "📍 Use my current location", geo_locating: "Locating…",
    geo_denied: "Location permission denied — you can still fill in District/State manually.",
    tags_label: "Tags (comma-separated)", photos_label: "Photos / Evidence (optional)", submit_btn: "Submit Problem",
    submitted_title: "Problem Submitted Successfully", problem_id_label: "Problem ID", go_dashboard: "Go to Dashboard",
    speak_lang_label: "Speak in",

    solutions_title: "Solutions", solutions_subtitle: "Collaborative solutions proposed by students, universities, and industry across all problems.",
    all_solutions: "All solutions", my_solutions: "My proposed solutions", no_solutions_found: "No solutions found.",

    profile_title: "My Profile", edit_profile: "Edit Profile", save_changes: "Save Changes",
    org_profile_title: "Organization Profile", save_org: "Save Organization",
    no_badges: "No badges earned yet — report a verified problem or get a solution accepted to start earning them.",
    contribution_points: "contribution points", stat_reported_short: "Reported", stat_solutions_short: "Solutions", stat_supported_short: "Supported",
    skills_label: "Skills (comma-separated)", bio_label: "Bio",

    notifications_title: "Notifications", no_notifications: "No notifications yet.", mark_read: "Mark read",

    admin_title: "Admin Dashboard", admin_subtitle: "Platform-wide oversight and moderation.",
    problems_by_category: "Problems by Category", pending_verification: "Pending Verification", all_caught_up: "Nothing pending — all caught up.",
    all_users: "All Users", verify_btn: "Verify", reject_btn: "Reject", view_btn: "View",
    admin_stat_users: "Total Users", admin_stat_problems: "Total Problems", admin_stat_pending: "Pending Verification",
    admin_stat_active: "Active Projects", admin_stat_resolved: "Resolved Problems", admin_stat_orgs: "Organizations",
    verified_toast: "Problem verified.", rejected_toast: "Problem rejected.",

    status_Submitted: "Submitted", status_Under_Review: "Under Review", status_Verified: "Verified", status_Assigned: "Assigned",
    status_Solution_Proposed: "Solution Proposed", status_In_Progress: "In Progress", status_Resolved: "Resolved",
    status_Closed: "Closed", status_Rejected: "Rejected", status_Proposed: "Proposed", status_Accepted: "Accepted", status_Completed: "Completed",
    severity_Low: "Low", severity_Medium: "Medium", severity_High: "High", severity_Critical: "Critical",
    cat_Education: "Education", cat_Healthcare: "Healthcare", cat_Agriculture: "Agriculture",
    "cat_Water & Sanitation": "Water & Sanitation", cat_Infrastructure: "Infrastructure", cat_Environment: "Environment",
    cat_Employment: "Employment", "cat_Public Safety": "Public Safety", cat_Transportation: "Transportation", cat_Other: "Other",
  },

  hi: {
    nav_home: "होम", nav_problems: "समस्याएँ", nav_solutions: "समाधान", nav_how: "यह कैसे काम करता है",
    nav_login: "लॉग इन", nav_register: "पंजीकरण", nav_dashboard: "डैशबोर्ड", nav_report: "रिपोर्ट करें",
    nav_profile: "प्रोफ़ाइल", nav_admin: "एडमिन", nav_logout: "लॉग आउट",

    hero_title: "स्थानीय समस्याओं को सामूहिक समाधान में बदलें।",
    hero_badge: "🤝 नागरिक + छात्र + उद्योग, साथ में",
    hero_desc: "अपने समुदाय को प्रभावित करने वाली समस्याओं की रिपोर्ट करें। विश्वविद्यालय, छात्र, उद्योग और एनजीओ आपके साथ मिलकर वास्तविक समाधान डिज़ाइन, प्रस्तावित और लागू करते हैं — हर कदम पारदर्शी रूप से ट्रैक किया जाता है।",
    hero_report: "समस्या रिपोर्ट करें", hero_explore: "समस्याएँ देखें",
    sync_live: "जुड़ा हुआ", sync_offline: "ऑफ़लाइन",
    compare_title: "प्रतिक्रिया समय, पहले बनाम बाद में", compare_traditional: "पारंपरिक प्रक्रिया",
    compare_jansetu: "जनसेतु के साथ", compare_note: "उदाहरण के लिए तुलना — यह प्लेटफ़ॉर्म का मापा गया डेटा नहीं है।", compare_jansetu_days: "6 दिन",
    stat_reported: "रिपोर्ट की गई समस्याएँ", stat_solved: "हल हुई समस्याएँ", stat_contributors: "सक्रिय योगदानकर्ता", stat_orgs: "भाग लेने वाले संगठन",
    how_title: "यह कैसे काम करता है", how_desc: "रिपोर्ट की गई समस्या से वास्तविक समाधान तक।",
    step1_t: "रिपोर्ट करें", step1_d: "नागरिक विवरण, स्थान और प्रमाण के साथ स्थानीय समस्या रिपोर्ट करते हैं।",
    step2_t: "सत्यापित करें", step2_d: "समुदाय और प्रशासक इसकी पुष्टि और प्राथमिकता तय करते हैं।",
    step3_t: "सहयोग करें", step3_d: "छात्र, विश्वविद्यालय और उद्योग समाधान प्रस्तावित करते हैं।",
    step4_t: "समाधान करें", step4_d: "सर्वश्रेष्ठ समाधान स्वीकार और लागू किया जाता है।",
    step5_t: "प्रभाव ट्रैक करें", step5_d: "हर कोई समस्या को समाधान तक फॉलो कर सकता है।",
    categories_title: "श्रेणी अनुसार देखें", featured_title: "प्रमुख समस्याएँ",
    login_to_explore: "समस्याएँ देखने के लिए लॉग इन करें",
    track_title: "समस्या ट्रैक करें", track_placeholder: "समस्या आईडी दर्ज करें (जैसे JS-2026-00021)", track_btn: "ट्रैक करें",
    track_not_found: "इस आईडी से कोई समस्या नहीं मिली।",

    login_title: "वापसी पर स्वागत है", login_subtitle: "जनसेतु पर सहयोग जारी रखने के लिए लॉग इन करें।",
    email: "ईमेल", password: "पासवर्ड", remember_me: "मुझे याद रखें", forgot_password: "पासवर्ड भूल गए?",
    login_btn: "लॉग इन करें", new_here: "नए हैं?", create_account: "खाता बनाएं",
    demo_accounts_note: "डेमो खाते (पासवर्ड: password123): citizen@demo.com · student@demo.com · university@demo.com · industry@demo.com · ngo@demo.com · expert@demo.com · admin@demo.com",
    forgot_alert: "इस प्रोटोटाइप में पासवर्ड रीसेट अभी उपलब्ध नहीं है — नीचे दिए गए डेमो खातों में से किसी का उपयोग करें, या नया खाता बनाएं।",

    register_title: "अपना खाता बनाएं", register_subtitle: "नागरिकों, छात्रों, विश्वविद्यालयों, उद्योग और एनजीओ के साथ मिलकर समस्याएं हल करें।",
    full_name: "पूरा नाम", phone: "फ़ोन", confirm_password: "पासवर्ड की पुष्टि करें", location: "स्थान", i_am_a: "मैं हूँ...",
    already_have_account: "पहले से खाता है?", log_in: "लॉग इन करें", create_account_btn: "खाता बनाएं",

    role_citizen: "नागरिक", role_student: "छात्र", role_university: "विश्वविद्यालय", role_industry: "उद्योग", role_ngo: "एनजीओ", role_expert: "विशेषज्ञ", role_admin: "एडमिन",

    dash_welcome: "वापसी पर स्वागत है", dash_subtitle: "आपके योगदान से जुड़ी जानकारी यहाँ है।",
    dash_report_btn: "समस्या रिपोर्ट करें", dash_explore_btn: "समस्याएँ देखें", dash_contrib_btn: "मेरा योगदान", dash_notif_btn: "सूचनाएं",
    dash_my_problems: "मेरी समस्याएँ", dash_activity: "हाल की गतिविधि",
    dash_no_problems: "आपने अभी तक कोई समस्या रिपोर्ट नहीं की है।", dash_report_first: "अपनी पहली समस्या रिपोर्ट करें",
    dash_no_activity: "अभी तक कोई हालिया गतिविधि नहीं है।",
    dash_reported: "रिपोर्ट की गई समस्याएँ", dash_review: "समीक्षा में", dash_solving: "हल हो रही हैं", dash_resolved: "हल हो गईं",

    explore_title: "समस्याएँ देखें", explore_subtitle: "अपने लिए महत्वपूर्ण समस्याओं को खोजें, फ़िल्टर करें और समर्थन दें।",
    search_placeholder: "समस्याएँ खोजें…", all_categories: "सभी श्रेणियाँ", all_severities: "सभी गंभीरता स्तर", all_statuses: "सभी स्थितियाँ",
    sort_recent: "सबसे हालिया", sort_supported: "सबसे अधिक समर्थित", sort_priority: "उच्चतम प्राथमिकता",
    no_problems_match: "इन फ़िल्टर से कोई समस्या मेल नहीं खाती।", support_btn: "समर्थन करें", supported_btn: "समर्थित",

    back_to_problems: "← समस्याओं पर वापस जाएं", propose_solution_btn: "💡 समाधान प्रस्तावित करें", share_btn: "🔗 शेयर करें",
    you_reported: "आपने यह समस्या रिपोर्ट की", link_copied: "लिंक क्लिपबोर्ड पर कॉपी हो गया।",
    status_timeline: "स्थिति समयरेखा", proposed_solutions: "प्रस्तावित समाधान", discussion: "चर्चा",
    add_comment_placeholder: "टिप्पणी जोड़ें…", post_btn: "पोस्ट करें", no_comments: "अभी तक कोई टिप्पणी नहीं — चर्चा शुरू करें।",
    snapshot_title: "समस्या सारांश", snapshot_status: "स्थिति", snapshot_severity: "गंभीरता", snapshot_supporters: "समर्थक", snapshot_tags: "टैग",
    update_status_label: "स्थिति अपडेट करें (मॉडरेटर)", update_btn: "अपडेट करें", no_solutions_yet: "अभी तक कोई समाधान प्रस्तावित नहीं।",
    accept_solution_btn: "समाधान स्वीकार करें", vote_btn: "वोट",
    propose_form_title: "समाधान प्रस्तावित करें", solution_title_label: "समाधान शीर्षक", description_label: "विवरण",
    est_cost_label: "अनुमानित लागत (₹)", est_time_label: "अनुमानित समय", required_resources_label: "आवश्यक संसाधन",
    submit_proposal_btn: "प्रस्ताव सबमिट करें", solution_proposed_toast: "समाधान प्रस्तावित किया गया!", thanks_support: "इस समस्या का समर्थन करने के लिए धन्यवाद!",
    status_updated_toast: "स्थिति अपडेट हो गई।", solution_accepted_toast: "समाधान स्वीकार कर लिया गया!",

    report_title: "स्थानीय समस्या रिपोर्ट करें", report_subtitle: "समस्या को स्पष्ट रूप से बताएं — एक नागरिक एक मिनट से भी कम समय में समस्या रिपोर्ट कर सके।",
    title_label: "समस्या शीर्षक", speak_hint: "टाइप करने के बजाय अपनी समस्या बोलने के लिए माइक दबाएं।",
    listening: "सुन रहा है…", demo_transcript_note: "डेमो लिखित पाठ जोड़ा गया — आवश्यकतानुसार संपादित करें।",
    category_label: "श्रेणी", severity_label: "गंभीरता", district_label: "ज़िला", state_label: "राज्य",
    location_label: "स्थान", use_location_btn: "📍 मेरा वर्तमान स्थान उपयोग करें", geo_locating: "स्थान ढूंढा जा रहा है…",
    geo_denied: "स्थान की अनुमति नहीं मिली — आप ज़िला/राज्य मैन्युअल रूप से भर सकते हैं।",
    tags_label: "टैग (कॉमा से अलग करें)", photos_label: "फ़ोटो / प्रमाण (वैकल्पिक)", submit_btn: "समस्या सबमिट करें",
    submitted_title: "समस्या सफलतापूर्वक सबमिट हुई", problem_id_label: "समस्या आईडी", go_dashboard: "डैशबोर्ड पर जाएं",
    speak_lang_label: "इस भाषा में बोलें",

    solutions_title: "समाधान", solutions_subtitle: "सभी समस्याओं में छात्रों, विश्वविद्यालयों और उद्योग द्वारा प्रस्तावित सामूहिक समाधान।",
    all_solutions: "सभी समाधान", my_solutions: "मेरे प्रस्तावित समाधान", no_solutions_found: "कोई समाधान नहीं मिला।",

    profile_title: "मेरी प्रोफ़ाइल", edit_profile: "प्रोफ़ाइल संपादित करें", save_changes: "परिवर्तन सहेजें",
    org_profile_title: "संगठन प्रोफ़ाइल", save_org: "संगठन सहेजें",
    no_badges: "अभी तक कोई बैज नहीं मिला — सत्यापित समस्या रिपोर्ट करें या समाधान स्वीकृत करवाएं।",
    contribution_points: "योगदान अंक", stat_reported_short: "रिपोर्ट की गईं", stat_solutions_short: "समाधान", stat_supported_short: "समर्थित",
    skills_label: "कौशल (कॉमा से अलग करें)", bio_label: "बायो",

    notifications_title: "सूचनाएं", no_notifications: "अभी तक कोई सूचना नहीं।", mark_read: "पढ़ा हुआ चिह्नित करें",

    admin_title: "एडमिन डैशबोर्ड", admin_subtitle: "प्लेटफ़ॉर्म-व्यापी निगरानी और मॉडरेशन।",
    problems_by_category: "श्रेणी अनुसार समस्याएँ", pending_verification: "सत्यापन लंबित", all_caught_up: "कुछ भी लंबित नहीं — सब पूरा हो गया।",
    all_users: "सभी उपयोगकर्ता", verify_btn: "सत्यापित करें", reject_btn: "अस्वीकार करें", view_btn: "देखें",
    admin_stat_users: "कुल उपयोगकर्ता", admin_stat_problems: "कुल समस्याएँ", admin_stat_pending: "सत्यापन लंबित",
    admin_stat_active: "सक्रिय परियोजनाएं", admin_stat_resolved: "हल हुई समस्याएँ", admin_stat_orgs: "संगठन",
    verified_toast: "समस्या सत्यापित हो गई।", rejected_toast: "समस्या अस्वीकृत कर दी गई।",

    status_Submitted: "सबमिट किया गया", status_Under_Review: "समीक्षा में", status_Verified: "सत्यापित", status_Assigned: "सौंपा गया",
    status_Solution_Proposed: "समाधान प्रस्तावित", status_In_Progress: "प्रगति में", status_Resolved: "हल हो गया",
    status_Closed: "बंद", status_Rejected: "अस्वीकृत", status_Proposed: "प्रस्तावित", status_Accepted: "स्वीकृत", status_Completed: "पूर्ण",
    severity_Low: "कम", severity_Medium: "मध्यम", severity_High: "उच्च", severity_Critical: "गंभीर",
    cat_Education: "शिक्षा", cat_Healthcare: "स्वास्थ्य सेवा", cat_Agriculture: "कृषि",
    "cat_Water & Sanitation": "जल एवं स्वच्छता", cat_Infrastructure: "बुनियादी ढांचा", cat_Environment: "पर्यावरण",
    cat_Employment: "रोजगार", "cat_Public Safety": "सार्वजनिक सुरक्षा", cat_Transportation: "परिवहन", cat_Other: "अन्य",
  },

  mr: {
    nav_home: "मुख्यपृष्ठ", nav_problems: "समस्या", nav_solutions: "उपाय", nav_how: "हे कसे कार्य करते",
    nav_login: "लॉगिन", nav_register: "नोंदणी", nav_dashboard: "डॅशबोर्ड", nav_report: "तक्रार नोंदवा",
    nav_profile: "प्रोफाइल", nav_admin: "अ‍ॅडमिन", nav_logout: "लॉगआउट",

    hero_title: "स्थानिक समस्यांना सामूहिक उपायांमध्ये रूपांतरित करा.",
    hero_badge: "🤝 नागरिक + विद्यार्थी + उद्योग, एकत्र",
    hero_desc: "तुमच्या समुदायावर परिणाम करणाऱ्या समस्या नोंदवा. विद्यापीठे, विद्यार्थी, उद्योग आणि स्वयंसेवी संस्था तुमच्यासोबत मिळून खरे उपाय तयार करतात — प्रत्येक टप्पा पारदर्शकपणे ट्रॅक केला जातो.",
    hero_report: "समस्या नोंदवा", hero_explore: "समस्या पहा",
    sync_live: "कनेक्ट झाले", sync_offline: "ऑफलाइन",
    compare_title: "प्रतिसाद वेळ, आधी वि. नंतर", compare_traditional: "पारंपरिक प्रक्रिया",
    compare_jansetu: "जनसेतुसह", compare_note: "उदाहरणादाखल तुलना — हा प्लॅटफॉर्मचा मोजलेला डेटा नाही.", compare_jansetu_days: "6 दिवस",
    stat_reported: "नोंदवलेल्या समस्या", stat_solved: "सोडवलेल्या समस्या", stat_contributors: "सक्रिय सहभागी", stat_orgs: "सहभागी संस्था",
    how_title: "हे कसे कार्य करते", how_desc: "नोंदवलेल्या समस्येपासून प्रत्यक्ष उपायापर्यंत.",
    step1_t: "नोंदवा", step1_d: "नागरिक तपशील, स्थान आणि पुराव्यासह स्थानिक समस्या नोंदवतात.",
    step2_t: "पडताळणी करा", step2_d: "समुदाय आणि प्रशासक याची पुष्टी आणि प्राधान्य ठरवतात.",
    step3_t: "सहकार्य करा", step3_d: "विद्यार्थी, विद्यापीठे आणि उद्योग उपाय सुचवतात.",
    step4_t: "सोडवा", step4_d: "सर्वोत्तम उपाय स्वीकारला आणि अंमलात आणला जातो.",
    step5_t: "परिणाम ट्रॅक करा", step5_d: "प्रत्येकजण समस्येचा निकालापर्यंतचा प्रवास पाहू शकतो.",
    categories_title: "श्रेणीनुसार पहा", featured_title: "ठळक समस्या",
    login_to_explore: "समस्या पाहण्यासाठी लॉगिन करा",
    track_title: "समस्या ट्रॅक करा", track_placeholder: "समस्या आयडी टाका (उदा. JS-2026-00021)", track_btn: "ट्रॅक करा",
    track_not_found: "या आयडीसह कोणतीही समस्या आढळली नाही.",

    login_title: "पुन्हा स्वागत आहे", login_subtitle: "जनसेतुवर सहकार्य सुरू ठेवण्यासाठी लॉगिन करा.",
    email: "ईमेल", password: "पासवर्ड", remember_me: "मला लक्षात ठेवा", forgot_password: "पासवर्ड विसरलात?",
    login_btn: "लॉगिन करा", new_here: "नवीन आहात?", create_account: "खाते तयार करा",
    demo_accounts_note: "डेमो खाती (पासवर्ड: password123): citizen@demo.com · student@demo.com · university@demo.com · industry@demo.com · ngo@demo.com · expert@demo.com · admin@demo.com",
    forgot_alert: "या प्रोटोटाइपमध्ये पासवर्ड रीसेट अद्याप उपलब्ध नाही — खालीलपैकी एक डेमो खाते वापरा किंवा नवीन नोंदणी करा.",

    register_title: "तुमचे खाते तयार करा", register_subtitle: "नागरिक, विद्यार्थी, विद्यापीठे, उद्योग आणि स्वयंसेवी संस्थांसोबत मिळून समस्या सोडवा.",
    full_name: "पूर्ण नाव", phone: "फोन", confirm_password: "पासवर्डची पुष्टी करा", location: "स्थान", i_am_a: "मी आहे...",
    already_have_account: "आधीच खाते आहे?", log_in: "लॉगिन करा", create_account_btn: "खाते तयार करा",

    role_citizen: "नागरिक", role_student: "विद्यार्थी", role_university: "विद्यापीठ", role_industry: "उद्योग", role_ngo: "एनजीओ", role_expert: "तज्ञ", role_admin: "अ‍ॅडमिन",

    dash_welcome: "पुन्हा स्वागत आहे", dash_subtitle: "तुमच्या योगदानाबद्दलची माहिती येथे आहे.",
    dash_report_btn: "समस्या नोंदवा", dash_explore_btn: "समस्या पहा", dash_contrib_btn: "माझे योगदान", dash_notif_btn: "सूचना",
    dash_my_problems: "माझ्या समस्या", dash_activity: "अलीकडील क्रियाकलाप",
    dash_no_problems: "तुम्ही अजून कोणतीही समस्या नोंदवलेली नाही.", dash_report_first: "तुमची पहिली समस्या नोंदवा",
    dash_no_activity: "अद्याप कोणतीही अलीकडील क्रियाकलाप नाही.",
    dash_reported: "नोंदवलेल्या समस्या", dash_review: "पुनरावलोकनात", dash_solving: "सोडवले जात आहे", dash_resolved: "सोडवले",

    explore_title: "समस्या पहा", explore_subtitle: "तुमच्यासाठी महत्त्वाच्या समस्या शोधा, फिल्टर करा आणि समर्थन द्या.",
    search_placeholder: "समस्या शोधा…", all_categories: "सर्व श्रेणी", all_severities: "सर्व तीव्रता", all_statuses: "सर्व स्थिती",
    sort_recent: "सर्वात अलीकडील", sort_supported: "सर्वाधिक समर्थित", sort_priority: "सर्वोच्च प्राधान्य",
    no_problems_match: "या फिल्टरशी जुळणारी कोणतीही समस्या नाही.", support_btn: "समर्थन द्या", supported_btn: "समर्थित",

    back_to_problems: "← समस्यांकडे परत जा", propose_solution_btn: "💡 उपाय सुचवा", share_btn: "🔗 शेअर करा",
    you_reported: "तुम्ही ही समस्या नोंदवली आहे", link_copied: "लिंक क्लिपबोर्डवर कॉपी झाली.",
    status_timeline: "स्थिती टाइमलाइन", proposed_solutions: "सुचवलेले उपाय", discussion: "चर्चा",
    add_comment_placeholder: "टिप्पणी जोडा…", post_btn: "पोस्ट करा", no_comments: "अद्याप कोणतीही टिप्पणी नाही — चर्चा सुरू करा.",
    snapshot_title: "समस्या सारांश", snapshot_status: "स्थिती", snapshot_severity: "तीव्रता", snapshot_supporters: "समर्थक", snapshot_tags: "टॅग",
    update_status_label: "स्थिती अद्यतनित करा (मॉडरेटर)", update_btn: "अद्यतनित करा", no_solutions_yet: "अद्याप कोणताही उपाय सुचवलेला नाही.",
    accept_solution_btn: "उपाय स्वीकारा", vote_btn: "मते",
    propose_form_title: "उपाय सुचवा", solution_title_label: "उपाय शीर्षक", description_label: "वर्णन",
    est_cost_label: "अंदाजे खर्च (₹)", est_time_label: "अंदाजे वेळ", required_resources_label: "आवश्यक संसाधने",
    submit_proposal_btn: "प्रस्ताव सबमिट करा", solution_proposed_toast: "उपाय सुचवला गेला!", thanks_support: "या समस्येला समर्थन दिल्याबद्दल धन्यवाद!",
    status_updated_toast: "स्थिती अद्यतनित केली.", solution_accepted_toast: "उपाय स्वीकारला गेला!",

    report_title: "स्थानिक समस्या नोंदवा", report_subtitle: "समस्या स्पष्टपणे सांगा — नागरिकाला एका मिनिटापेक्षा कमी वेळात समस्या नोंदवता आली पाहिजे.",
    title_label: "समस्या शीर्षक", speak_hint: "टाइप करण्याऐवजी तुमची समस्या बोलण्यासाठी माइक दाबा.",
    listening: "ऐकत आहे…", demo_transcript_note: "डेमो मजकूर घातला — आवश्यकतेनुसार संपादित करा.",
    category_label: "श्रेणी", severity_label: "तीव्रता", district_label: "जिल्हा", state_label: "राज्य",
    location_label: "स्थान", use_location_btn: "📍 माझे सध्याचे स्थान वापरा", geo_locating: "स्थान शोधत आहे…",
    geo_denied: "स्थान परवानगी नाकारली — तुम्ही जिल्हा/राज्य स्वहस्ते भरू शकता.",
    tags_label: "टॅग (स्वल्पविरामाने वेगळे करा)", photos_label: "फोटो / पुरावा (ऐच्छिक)", submit_btn: "समस्या सबमिट करा",
    submitted_title: "समस्या यशस्वीरित्या सबमिट झाली", problem_id_label: "समस्या आयडी", go_dashboard: "डॅशबोर्डवर जा",
    speak_lang_label: "या भाषेत बोला",

    solutions_title: "उपाय", solutions_subtitle: "सर्व समस्यांवर विद्यार्थी, विद्यापीठे आणि उद्योगांनी सुचवलेले सामूहिक उपाय.",
    all_solutions: "सर्व उपाय", my_solutions: "माझे सुचवलेले उपाय", no_solutions_found: "कोणतेही उपाय आढळले नाहीत.",

    profile_title: "माझी प्रोफाइल", edit_profile: "प्रोफाइल संपादित करा", save_changes: "बदल जतन करा",
    org_profile_title: "संस्था प्रोफाइल", save_org: "संस्था जतन करा",
    no_badges: "अद्याप कोणतेही बॅज मिळालेले नाहीत — सत्यापित समस्या नोंदवा किंवा उपाय स्वीकारला जाऊ द्या.",
    contribution_points: "योगदान गुण", stat_reported_short: "नोंदवलेल्या", stat_solutions_short: "उपाय", stat_supported_short: "समर्थित",
    skills_label: "कौशल्ये (स्वल्पविरामाने वेगळे करा)", bio_label: "बायो",

    notifications_title: "सूचना", no_notifications: "अद्याप कोणतीही सूचना नाही.", mark_read: "वाचले म्हणून चिन्हांकित करा",

    admin_title: "अ‍ॅडमिन डॅशबोर्ड", admin_subtitle: "प्लॅटफॉर्म-व्यापी देखरेख आणि नियमन.",
    problems_by_category: "श्रेणीनुसार समस्या", pending_verification: "पडताळणी प्रलंबित", all_caught_up: "काहीही प्रलंबित नाही — सर्व पूर्ण झाले.",
    all_users: "सर्व वापरकर्ते", verify_btn: "पडताळणी करा", reject_btn: "नाकारा", view_btn: "पहा",
    admin_stat_users: "एकूण वापरकर्ते", admin_stat_problems: "एकूण समस्या", admin_stat_pending: "पडताळणी प्रलंबित",
    admin_stat_active: "सक्रिय प्रकल्प", admin_stat_resolved: "सोडवलेल्या समस्या", admin_stat_orgs: "संस्था",
    verified_toast: "समस्या पडताळली गेली.", rejected_toast: "समस्या नाकारली गेली.",

    status_Submitted: "सबमिट केले", status_Under_Review: "पुनरावलोकनात", status_Verified: "पडताळले", status_Assigned: "नियुक्त केले",
    status_Solution_Proposed: "उपाय सुचवला", status_In_Progress: "प्रगतीपथावर", status_Resolved: "सोडवले",
    status_Closed: "बंद", status_Rejected: "नाकारले", status_Proposed: "सुचवले", status_Accepted: "स्वीकारले", status_Completed: "पूर्ण",
    severity_Low: "कमी", severity_Medium: "मध्यम", severity_High: "उच्च", severity_Critical: "गंभीर",
    cat_Education: "शिक्षण", cat_Healthcare: "आरोग्यसेवा", cat_Agriculture: "शेती",
    "cat_Water & Sanitation": "पाणी व स्वच्छता", cat_Infrastructure: "पायाभूत सुविधा", cat_Environment: "पर्यावरण",
    cat_Employment: "रोजगार", "cat_Public Safety": "सार्वजनिक सुरक्षा", cat_Transportation: "वाहतूक", cat_Other: "इतर",
  },
};

const I18N_SPEECH_LANG = { en: "en-IN", hi: "hi-IN", mr: "mr-IN" };
const I18N_LANG_LABELS = { en: "EN", hi: "हिं", mr: "मरा" };

const I18n = {
  current() {
    return localStorage.getItem("jansetu_lang") || "en";
  },
  set(lang) {
    localStorage.setItem("jansetu_lang", lang);
    window.location.reload();
  },
  speechLang() {
    return I18N_SPEECH_LANG[this.current()] || "en-IN";
  },
};

function t(key) {
  const lang = I18n.current();
  return (I18N_DICTS[lang] && I18N_DICTS[lang][key]) || I18N_DICTS.en[key] || key;
}

function trStatus(status) {
  return t(`status_${(status || "").replace(/ /g, "_")}`);
}
function trSeverity(sev) {
  return t(`severity_${sev}`);
}
function trCategory(cat) {
  return t(`cat_${cat}`);
}

const CATEGORY_VALUES = ["Education", "Healthcare", "Agriculture", "Water & Sanitation", "Infrastructure", "Environment", "Employment", "Public Safety", "Transportation", "Other"];
const SEVERITY_VALUES = ["Low", "Medium", "High", "Critical"];
const STATUS_VALUES = ["Submitted", "Under Review", "Verified", "Assigned", "Solution Proposed", "In Progress", "Resolved", "Closed", "Rejected"];

// Populates a <select> with English values (sent to the API) but
// translated display labels, optionally with a leading "All ..." option.
function populateSelect(selectEl, values, translateFn, opts = {}) {
  const { allLabel, selected } = opts;
  let html = allLabel ? `<option value="">${allLabel}</option>` : "";
  html += values.map((v) => `<option value="${v}" ${v === selected ? "selected" : ""}>${translateFn(v)}</option>`).join("");
  selectEl.innerHTML = html;
}

// Applies translations to any static element carrying data-i18n / data-i18n-placeholder.
function applyI18n() {
  document.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((el) => { el.placeholder = t(el.dataset.i18nPlaceholder); });
  document.documentElement.lang = I18n.current();
}

function renderLangSwitcher() {
  const current = I18n.current();
  return `
    <div class="lang-switch" id="lang-switch">
      ${Object.keys(I18N_LANG_LABELS).map((code) => `<button data-lang="${code}" class="${code === current ? "active" : ""}">${I18N_LANG_LABELS[code]}</button>`).join("")}
    </div>
  `;
}

function wireLangSwitcher() {
  const el = document.getElementById("lang-switch");
  if (!el) return;
  el.querySelectorAll("[data-lang]").forEach((btn) => {
    btn.addEventListener("click", () => I18n.set(btn.dataset.lang));
  });
}
