renderNav("admin");
Auth.requireLogin();
Auth.requireRole("admin");
applyI18n();

async function load() {
  try {
    const [stats, pending, allProblems, users] = await Promise.all([
      api.get("/admin/stats"),
      api.get("/admin/problems/pending"),
      api.get("/admin/problems"),
      api.get("/admin/users"),
    ]);

    document.getElementById("stats").innerHTML = `
      <div class="stat-card"><div class="stat-num" id="a1">0</div><div class="stat-label">${t("admin_stat_users")}</div></div>
      <div class="stat-card"><div class="stat-num" id="a2">0</div><div class="stat-label">${t("admin_stat_problems")}</div></div>
      <div class="stat-card"><div class="stat-num" id="a3">0</div><div class="stat-label">${t("admin_stat_pending")}</div></div>
      <div class="stat-card"><div class="stat-num" id="a4">0</div><div class="stat-label">${t("admin_stat_active")}</div></div>
      <div class="stat-card"><div class="stat-num" id="a5">0</div><div class="stat-label">${t("admin_stat_resolved")}</div></div>
      <div class="stat-card"><div class="stat-num" id="a6">0</div><div class="stat-label">${t("admin_stat_orgs")}</div></div>
    `;
    animateNumber(document.getElementById("a1"), stats.totalUsers);
    animateNumber(document.getElementById("a2"), stats.totalProblems);
    animateNumber(document.getElementById("a3"), stats.pendingVerification);
    animateNumber(document.getElementById("a4"), stats.activeProjects);
    animateNumber(document.getElementById("a5"), stats.resolvedProblems);
    animateNumber(document.getElementById("a6"), stats.totalOrganizations);

    const byCategory = {};
    allProblems.forEach((p) => { byCategory[p.category] = (byCategory[p.category] || 0) + 1; });
    const max = Math.max(...Object.values(byCategory), 1);
    document.getElementById("category-chart").innerHTML = Object.entries(byCategory).map(([cat, count]) => `
      <div class="bar-row">
        <div class="bar-label">${trCategory(cat)}</div>
        <div class="bar-track"><div class="bar-fill" style="width:${(count / max) * 100}%"></div></div>
        <div>${count}</div>
      </div>
    `).join("") || `<p>—</p>`;

    const pendingEl = document.getElementById("pending");
    pendingEl.innerHTML = !pending.length ? `<div class="empty-state">${t("all_caught_up")}</div>` : pending.map((p) => `
      <div class="card fade-in" style="margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;">
        <div>
          <strong>${escapeHtml(p.title)}</strong>
          <div class="problem-meta"><span>🏷 ${trCategory(p.category)}</span><span>📍 ${escapeHtml(p.district || "—")}</span><span class="pill ${severityClass(p.severity)}">${trSeverity(p.severity)}</span></div>
        </div>
        <div style="display:flex;gap:8px;">
          <button class="btn btn-primary btn-sm" data-verify="${p._id}">${t("verify_btn")}</button>
          <button class="btn btn-outline btn-sm" data-reject="${p._id}">${t("reject_btn")}</button>
          <a href="problem-details.html?id=${p._id}" class="btn btn-outline btn-sm">${t("view_btn")}</a>
        </div>
      </div>
    `).join("");

    pendingEl.querySelectorAll("[data-verify]").forEach((btn) => btn.addEventListener("click", async () => {
      await api.patch(`/problems/${btn.dataset.verify}/status`, { status: "Verified", note: "Verified by admin." });
      showToast(t("verified_toast")); load();
    }));
    pendingEl.querySelectorAll("[data-reject]").forEach((btn) => btn.addEventListener("click", async () => {
      await api.patch(`/problems/${btn.dataset.reject}/status`, { status: "Rejected", note: "Rejected by admin." });
      showToast(t("rejected_toast")); load();
    }));

    const ROLE_LABEL = { citizen: "role_citizen", student: "role_student", university: "role_university", industry: "role_industry", ngo: "role_ngo", expert: "role_expert", admin: "role_admin" };
    document.getElementById("users").innerHTML = `
      <div class="card">
        <table style="width:100%;border-collapse:collapse;font-size:13.5px;">
          <thead><tr style="text-align:left;border-bottom:1px solid var(--border);"><th style="padding:8px 4px;">${t("full_name")}</th><th>${t("email")}</th><th></th><th></th></tr></thead>
          <tbody>
            ${users.map((u) => `<tr style="border-bottom:1px solid var(--border);"><td style="padding:8px 4px;">${escapeHtml(u.fullName)}</td><td>${escapeHtml(u.email)}</td><td><span class="role-pill">${t(ROLE_LABEL[u.userType] || u.userType)}</span></td><td>${u.points || 0}</td></tr>`).join("")}
          </tbody>
        </table>
      </div>
    `;
  } catch (err) {
    showToast(err.message, "error");
  }
}

load();
