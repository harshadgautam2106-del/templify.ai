renderNav("problems");
Auth.requireLogin();
applyI18n();

populateSelect(document.getElementById("category-filter"), CATEGORY_VALUES, trCategory, { allLabel: t("all_categories") });
populateSelect(document.getElementById("severity-filter"), SEVERITY_VALUES, trSeverity, { allLabel: t("all_severities") });
populateSelect(document.getElementById("status-filter"), STATUS_VALUES, trStatus, { allLabel: t("all_statuses") });
document.getElementById("sort-filter").innerHTML = `
  <option value="recent">${t("sort_recent")}</option>
  <option value="supported">${t("sort_supported")}</option>
  <option value="priority">${t("sort_priority")}</option>
`;

const params = new URLSearchParams(window.location.search);
if (params.get("category")) document.getElementById("category-filter").value = params.get("category");

let allProblems = [];

async function loadProblems() {
  const resultsEl = document.getElementById("results");
  resultsEl.innerHTML = `<div class="loading-state">…</div>`;
  try {
    const query = new URLSearchParams();
    const category = document.getElementById("category-filter").value;
    const severity = document.getElementById("severity-filter").value;
    const status = document.getElementById("status-filter").value;
    const sort = document.getElementById("sort-filter").value;
    const q = document.getElementById("search-input").value.trim();
    if (category) query.set("category", category);
    if (severity) query.set("severity", severity);
    if (status) query.set("status", status);
    if (sort) query.set("sort", sort);
    if (q) query.set("q", q);

    allProblems = await api.get(`/problems?${query.toString()}`);
    renderResults(allProblems);
  } catch (err) {
    resultsEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
  }
}

function renderResults(list) {
  const resultsEl = document.getElementById("results");
  if (!list.length) {
    resultsEl.innerHTML = `<div class="empty-state">${t("no_problems_match")}</div>`;
    return;
  }
  const user = Auth.getUser();
  resultsEl.innerHTML = `<div class="problem-grid">` + list.map((p) => `
    <div class="card problem-card">
      <a href="problem-details.html?id=${p._id}" style="display:block;">
        <div class="problem-card-top">
          <h3>${escapeHtml(p.title)}</h3>
          <span class="pill ${severityClass(p.severity)}">${trSeverity(p.severity)}</span>
        </div>
        <p style="font-size:11.5px;color:var(--muted);margin-bottom:4px;">${escapeHtml(p.problemCode || "")}</p>
        <p>${escapeHtml(p.description).slice(0, 110)}…</p>
        <div class="problem-meta">
          <span>🏷 ${trCategory(p.category)}</span>
          <span>📍 ${escapeHtml(p.district || "—")}</span>
          <span class="pill ${statusClass(p.status)}">${trStatus(p.status)}</span>
        </div>
      </a>
      <div class="problem-footer">
        <span>👥 ${p.supportCount || 0} · ${timeAgo(p.createdAt)}</span>
        ${p.reporterId === user._id ? "" : `<button class="confirm-btn" data-support="${p._id}">✓ ${t("support_btn")}</button>`}
      </div>
    </div>
  `).join("") + `</div>`;

  resultsEl.querySelectorAll("[data-support]").forEach((btn) => {
    btn.addEventListener("click", async (e) => {
      e.preventDefault();
      try {
        await api.post(`/problems/${btn.dataset.support}/support`);
        showToast(t("thanks_support"));
        loadProblems();
      } catch (err) {
        showToast(err.message, "error");
      }
    });
  });
}

["category-filter", "severity-filter", "status-filter", "sort-filter"].forEach((id) => {
  document.getElementById(id).addEventListener("change", loadProblems);
});
let searchTimeout;
document.getElementById("search-input").addEventListener("input", () => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(loadProblems, 350);
});

loadProblems();
