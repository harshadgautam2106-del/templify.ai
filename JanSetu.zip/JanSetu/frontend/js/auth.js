// auth.js — session helpers shared by every page, plus the shared nav bar.
const Auth = {
  getUser() {
    const raw = localStorage.getItem("jansetu_user");
    return raw ? JSON.parse(raw) : null;
  },
  getToken() {
    return localStorage.getItem("jansetu_token");
  },
  isLoggedIn() {
    return !!this.getToken();
  },
  save(token, user) {
    localStorage.setItem("jansetu_token", token);
    localStorage.setItem("jansetu_user", JSON.stringify(user));
  },
  async logout() {
    try { await api.post("/auth/logout"); } catch {}
    localStorage.removeItem("jansetu_token");
    localStorage.removeItem("jansetu_user");
    window.location.href = "index.html";
  },
  requireLogin() {
    if (!this.isLoggedIn()) window.location.href = "login.html";
  },
  requireRole(...roles) {
    const user = this.getUser();
    if (!user || !roles.includes(user.userType)) {
      window.location.href = "dashboard.html";
    }
  },
};

// ---- Shared nav bar, injected into <div id="nav-placeholder"></div> ----
function renderNav(activePage = "") {
  const placeholder = document.getElementById("nav-placeholder");
  if (!placeholder) return;
  const user = Auth.getUser();

  const link = (href, label, key) =>
    `<a href="${href}" class="${activePage === key ? "active" : ""}">${label}</a>`;

  const loggedOutLinks = `
    ${link("index.html", t("nav_home"), "home")}
    ${link("problems.html", t("nav_problems"), "problems")}
    ${link("index.html#how-it-works", t("nav_how"), "how")}
    ${link("login.html", t("nav_login"), "login")}
    ${link("register.html", t("nav_register"), "register")}
  `;

  const loggedInLinks = `
    ${link("dashboard.html", t("nav_dashboard"), "dashboard")}
    ${link("problems.html", t("nav_problems"), "problems")}
    ${link("solutions.html", t("nav_solutions"), "solutions")}
    ${link("submit-problem.html", t("nav_report"), "report")}
    ${link("profile.html", t("nav_profile"), "profile")}
    ${user && user.userType === "admin" ? link("admin.html", t("nav_admin"), "admin") : ""}
    <a href="notifications.html" class="notif-bell" title="${t("notifications_title")}">🔔<span id="notif-count" class="notif-badge" style="display:none;">0</span></a>
    <a href="#" id="logout-link">${t("nav_logout")}</a>
  `;

  placeholder.innerHTML = `
    <header class="site-header">
      <div class="nav-inner">
        <a href="index.html" class="logo">
          <span class="logo-icon">⚡</span>
          <span class="logo-text">
            <span class="logo-mark">JanSetu</span>
            <span class="logo-tagline">Connect. Collaborate. Solve.</span>
          </span>
        </a>
        <nav class="nav-links" id="nav-links">${Auth.isLoggedIn() ? loggedInLinks : loggedOutLinks}</nav>
        <div class="nav-cta">
          <span class="sync-badge" id="sync-badge"><span class="dot"></span><span id="sync-label">…</span></span>
          ${renderLangSwitcher()}
          <button class="nav-toggle" id="nav-toggle">☰</button>
        </div>
      </div>
    </header>
  `;

  const toggle = document.getElementById("nav-toggle");
  if (toggle) toggle.addEventListener("click", () => document.getElementById("nav-links").classList.toggle("open"));

  const logoutLink = document.getElementById("logout-link");
  if (logoutLink) logoutLink.addEventListener("click", (e) => { e.preventDefault(); Auth.logout(); });

  wireLangSwitcher();
  applyI18n();
  checkBackendHealth();

  if (Auth.isLoggedIn()) loadUnreadCount();
}

async function checkBackendHealth() {
  const badge = document.getElementById("sync-badge");
  const label = document.getElementById("sync-label");
  if (!badge) return;
  try {
    const res = await fetch(`${API_BASE}/health`);
    if (!res.ok) throw new Error();
    badge.classList.remove("offline");
    label.textContent = t("sync_live");
  } catch {
    badge.classList.add("offline");
    label.textContent = t("sync_offline");
  }
}

async function loadUnreadCount() {
  try {
    const { count } = await api.get("/notifications/unread-count");
    const el = document.getElementById("notif-count");
    if (el) {
      if (count > 0) { el.textContent = count; el.style.display = "inline-block"; }
      else el.style.display = "none";
    }
  } catch {}
}
