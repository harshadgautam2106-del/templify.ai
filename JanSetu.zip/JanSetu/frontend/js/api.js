// api.js — every page's fetch calls go through this module.
const API_BASE = "http://localhost:5000/api";

let pendingRequests = 0;
function ensureProgressBar() {
  let bar = document.getElementById("top-progress");
  if (!bar) {
    bar = document.createElement("div");
    bar.id = "top-progress";
    document.body.appendChild(bar);
  }
  return bar;
}
function startProgress() {
  pendingRequests++;
  const bar = ensureProgressBar();
  bar.classList.add("active");
  bar.style.width = "70%";
}
function stopProgress() {
  pendingRequests = Math.max(0, pendingRequests - 1);
  const bar = ensureProgressBar();
  bar.style.width = "100%";
  if (pendingRequests === 0) {
    setTimeout(() => { bar.classList.remove("active"); bar.style.width = "0%"; }, 250);
  }
}

async function apiRequest(path, { method = "GET", body, isForm = false } = {}) {
  const token = localStorage.getItem("jansetu_token");
  const headers = {};
  if (!isForm) headers["Content-Type"] = "application/json";
  if (token) headers["Authorization"] = `Bearer ${token}`;

  startProgress();
  try {
    const res = await fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body ? (isForm ? body : JSON.stringify(body)) : undefined,
    });

    const contentType = res.headers.get("content-type") || "";
    const data = contentType.includes("application/json") ? await res.json().catch(() => ({})) : null;

    if (!res.ok) {
      const message = (data && data.error) || "Something went wrong. Please try again.";
      throw new Error(message);
    }
    return data;
  } finally {
    stopProgress();
  }
}

const api = {
  get: (path) => apiRequest(path),
  post: (path, body, isForm) => apiRequest(path, { method: "POST", body, isForm }),
  patch: (path, body) => apiRequest(path, { method: "PATCH", body }),
  delete: (path) => apiRequest(path, { method: "DELETE" }),
};

function showToast(message, type = "success") {
  let toast = document.getElementById("app-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "app-toast";
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.className = `toast show ${type}`;
  setTimeout(() => toast.classList.remove("show"), 3200);
}

function qs(id) { return document.getElementById(id); }

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

function timeAgo(dateStr) {
  const diff = (Date.now() - new Date(dateStr).getTime()) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function severityClass(sev) { return `pill-severity-${(sev || "medium").toLowerCase()}`; }
function statusClass(status) {
  const s = (status || "").toLowerCase();
  if (s === "resolved" || s === "completed") return "pill-status-resolved";
  if (s === "rejected") return "pill-status-rejected";
  return "pill-status";
}

// Animates a number counting up from 0 to target inside the given element.
function animateNumber(el, target, duration = 700) {
  if (!el) return;
  const start = 0;
  const startTime = performance.now();
  el.classList.add("counting");
  function tick(now) {
    const progress = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(start + (target - start) * eased);
    if (progress < 1) requestAnimationFrame(tick);
    else el.textContent = target;
  }
  requestAnimationFrame(tick);
}
