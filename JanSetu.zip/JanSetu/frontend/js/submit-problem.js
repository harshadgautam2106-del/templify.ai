renderNav("report");
Auth.requireLogin();
applyI18n();

populateSelect(document.getElementById("category"), CATEGORY_VALUES, trCategory, { selected: "Water & Sanitation" });
populateSelect(document.getElementById("severity"), SEVERITY_VALUES, trSeverity, { selected: "Medium" });
document.getElementById("speak-lang").value = I18n.current();

let geo = {};

document.getElementById("geo-btn").addEventListener("click", () => {
  if (!navigator.geolocation) { document.getElementById("geo-status").textContent = "Geolocation not supported in this browser."; return; }
  document.getElementById("geo-status").textContent = t("geo_locating");
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      geo = { latitude: pos.coords.latitude, longitude: pos.coords.longitude };
      document.getElementById("geo-status").textContent = `📍 (${geo.latitude.toFixed(4)}, ${geo.longitude.toFixed(4)})`;
    },
    () => { document.getElementById("geo-status").textContent = t("geo_denied"); }
  );
});

// ---- Voice-to-text (browser Web Speech API, language-aware, graceful demo fallback) ----
const SPEECH_LANG_MAP = { en: "en-IN", hi: "hi-IN", mr: "mr-IN" };
const DEMO_TRANSCRIPTS = {
  en: "There is no proper drinking water supply in our area and residents have to travel far to fetch water.",
  hi: "हमारे क्षेत्र में उचित पेयजल आपूर्ति नहीं है और निवासियों को पानी लाने के लिए दूर जाना पड़ता है।",
  mr: "आमच्या भागात योग्य पिण्याच्या पाण्याचा पुरवठा नाही आणि रहिवाशांना पाणी आणण्यासाठी दूर जावे लागते.",
};

const micBtn = document.getElementById("mic-btn");
micBtn.addEventListener("click", () => {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const descField = document.getElementById("description");
  const hint = document.getElementById("mic-hint");
  const speakLang = document.getElementById("speak-lang").value;

  if (!SR) {
    hint.textContent = "Speech recognition isn't supported here — inserting a demo transcript instead.";
    micBtn.classList.add("recording");
    setTimeout(() => {
      descField.value = (descField.value ? descField.value + " " : "") + (DEMO_TRANSCRIPTS[speakLang] || DEMO_TRANSCRIPTS.en);
      micBtn.classList.remove("recording");
      hint.textContent = t("demo_transcript_note");
    }, 900);
    return;
  }

  const recognition = new SR();
  recognition.lang = SPEECH_LANG_MAP[speakLang] || "en-IN";
  recognition.interimResults = false;
  micBtn.classList.add("recording");
  hint.textContent = t("listening");
  recognition.start();
  recognition.onresult = (e) => {
    descField.value = (descField.value ? descField.value + " " : "") + e.results[0][0].transcript;
  };
  recognition.onerror = () => { hint.textContent = "Couldn't hear that — please try again or type instead."; };
  recognition.onend = () => { micBtn.classList.remove("recording"); if (hint.textContent === t("listening")) hint.textContent = t("speak_hint"); };
});

document.getElementById("problem-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const errorEl = document.getElementById("error");
  const btn = document.getElementById("submit-btn");
  errorEl.textContent = "";
  btn.disabled = true;
  btn.textContent = "…";

  try {
    const form = new FormData();
    form.append("title", document.getElementById("title").value);
    form.append("description", document.getElementById("description").value);
    form.append("category", document.getElementById("category").value);
    form.append("severity", document.getElementById("severity").value);
    form.append("district", document.getElementById("district").value);
    form.append("state", document.getElementById("state").value);
    form.append("tags", document.getElementById("tags").value);
    if (geo.latitude) { form.append("latitude", geo.latitude); form.append("longitude", geo.longitude); }
    const files = document.getElementById("images").files;
    for (let i = 0; i < files.length; i++) form.append("images", files[i]);

    const problem = await api.post("/problems", form, true);
    document.getElementById("form-wrap").style.display = "none";
    document.getElementById("success-wrap").style.display = "block";
    document.getElementById("success-wrap").classList.add("fade-in");
    document.getElementById("problem-code").textContent = problem.problemCode;
  } catch (err) {
    errorEl.textContent = err.message;
    btn.disabled = false;
    btn.textContent = t("submit_btn");
  }
});
