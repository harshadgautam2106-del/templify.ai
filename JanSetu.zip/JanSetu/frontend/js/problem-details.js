renderNav("problems");
Auth.requireLogin();

const user = Auth.getUser();
const problemId = new URLSearchParams(window.location.search).get("id");
const canModerate = ["admin", "university", "industry", "ngo"].includes(user.userType);
const canPropose = ["student", "university", "industry", "ngo", "expert"].includes(user.userType);

let problem = null;
let solutions = [];

async function load() {
  try {
    [problem, solutions] = await Promise.all([
      api.get(`/problems/${problemId}`),
      api.get(`/solutions/problem/${problemId}`),
    ]);
    render();
  } catch (err) {
    document.getElementById("content").innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
  }
}

function render() {
  const isMine = problem.reporterId === user._id;
  const supported = (problem.supporters || []).includes(user._id);

  document.getElementById("content").innerHTML = `
    <div class="page-header">
      <a href="problems.html" style="font-size:13.5px;color:var(--muted);">${t("back_to_problems")}</a>
    </div>

    <div class="two-col fade-in">
      <div>
        <div class="card">
          <div class="problem-card-top">
            <h1 style="font-size:24px;">${escapeHtml(problem.title)}</h1>
            <span class="pill ${severityClass(problem.severity)}">${trSeverity(problem.severity)}</span>
          </div>
          <p style="font-size:11.5px;color:var(--muted);">${escapeHtml(problem.problemCode || "")}</p>
          <div class="problem-meta" style="margin-bottom:14px;">
            <span>🏷 ${trCategory(problem.category)}</span>
            <span>📍 ${escapeHtml(problem.district || "—")}, ${escapeHtml(problem.state || "")}</span>
            <span class="pill ${statusClass(problem.status)}">${trStatus(problem.status)}</span>
            <span>👤 ${escapeHtml(problem.reporterName)}</span>
            <span>${timeAgo(problem.createdAt)}</span>
          </div>
          <p>${escapeHtml(problem.description)}</p>
          ${problem.images && problem.images.length ? `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">${problem.images.map((src) => `<img src="http://localhost:5000${src}" style="width:120px;height:90px;object-fit:cover;border-radius:8px;border:1px solid var(--border);">`).join("")}</div>` : ""}

          <div style="display:flex;gap:10px;margin-top:18px;flex-wrap:wrap;">
            ${!isMine ? `<button class="btn ${supported ? "btn-outline" : "btn-primary"}" id="support-btn" ${supported ? "disabled" : ""}>✓ ${supported ? t("supported_btn") : t("support_btn")} (${problem.supportCount || 0})</button>` : `<span class="role-pill" style="padding:10px 16px;">${t("you_reported")}</span>`}
            ${canPropose ? `<button class="btn btn-outline" id="propose-btn">${t("propose_solution_btn")}</button>` : ""}
            <button class="btn btn-outline" id="share-btn">${t("share_btn")}</button>
          </div>

          ${canModerate ? renderModeratorControls() : ""}
        </div>

        <div class="section-title">${t("status_timeline")}</div>
        <div class="card">
          <div class="timeline">
            ${STATUS_VALUES.filter((s) => s !== "Closed" && s !== "Rejected").map((s) => {
              const entry = (problem.statusHistory || []).find((h) => h.status === s);
              return `
                <div class="timeline-item">
                  <div class="timeline-dot ${entry ? "" : "pending"}"></div>
                  <div>
                    <div class="timeline-status">${entry ? "✓" : "○"} ${trStatus(s)}</div>
                    ${entry ? `<div class="timeline-note">${escapeHtml(entry.note || "")} · ${new Date(entry.date).toLocaleString()}</div>` : ""}
                  </div>
                </div>`;
            }).join("")}
          </div>
        </div>

        <div class="section-title">${t("proposed_solutions")} (${solutions.length})</div>
        <div id="solutions-list">${renderSolutions()}</div>

        <div id="propose-form-container"></div>

        <div class="section-title">${t("discussion")}</div>
        <div class="card">
          <div id="comments-list">
            ${problem.comments.length ? problem.comments.map(renderComment).join("") : `<p>${t("no_comments")}</p>`}
          </div>
          <form id="comment-form" class="input-row" style="margin-top:14px;">
            <textarea id="comment-text" placeholder="${t("add_comment_placeholder")}" style="min-height:44px;" required></textarea>
            <button class="btn btn-primary btn-sm">${t("post_btn")}</button>
          </form>
        </div>
      </div>

      <div>
        <div class="card">
          <h4>${t("snapshot_title")}</h4>
          <p style="margin-bottom:6px;"><strong>${t("snapshot_status")}:</strong> ${trStatus(problem.status)}</p>
          <p style="margin-bottom:6px;"><strong>${t("snapshot_severity")}:</strong> ${trSeverity(problem.severity)}</p>
          <p style="margin-bottom:6px;"><strong>${t("snapshot_supporters")}:</strong> ${problem.supportCount || 0}</p>
          <p style="margin-bottom:0;"><strong>${t("snapshot_tags")}:</strong> ${(problem.tags || []).join(", ") || "—"}</p>
        </div>
      </div>
    </div>
  `;

  attachEvents();
}

function renderModeratorControls() {
  return `
    <div style="margin-top:16px;padding-top:16px;border-top:1px solid var(--border);">
      <label style="font-size:12.5px;font-weight:700;display:block;margin-bottom:6px;">${t("update_status_label")}</label>
      <div style="display:flex;gap:8px;">
        <select id="status-select" style="width:auto;flex:1;">
          ${STATUS_VALUES.map((s) => `<option value="${s}" ${s === problem.status ? "selected" : ""}>${trStatus(s)}</option>`).join("")}
        </select>
        <button class="btn btn-primary btn-sm" id="update-status-btn">${t("update_btn")}</button>
      </div>
    </div>
  `;
}

function renderSolutions() {
  if (!solutions.length) return `<div class="empty-state">${t("no_solutions_yet")}</div>`;
  return solutions.map((s) => {
    const voted = (s.voters || []).includes(user._id);
    return `
      <div class="card solution-card">
        <div class="problem-card-top">
          <h4>${escapeHtml(s.title)}</h4>
          <span class="pill ${statusClass(s.status)}">${trStatus(s.status)}</span>
        </div>
        <p>${escapeHtml(s.description)}</p>
        <div class="problem-meta">
          <span>👤 ${escapeHtml(s.proposedByName)}</span>
          ${s.estimatedCost ? `<span>💰 ₹${Number(s.estimatedCost).toLocaleString("en-IN")}</span>` : ""}
          ${s.estimatedTime ? `<span>⏱ ${escapeHtml(s.estimatedTime)}</span>` : ""}
        </div>
        <div class="problem-footer">
          <button class="vote-btn ${voted ? "voted" : ""}" data-vote="${s._id}" ${voted ? "disabled" : ""}>▲ ${s.votes || 0} ${t("vote_btn")}</button>
          ${canModerate && s.status !== "Accepted" ? `<button class="btn btn-outline btn-sm" data-accept="${s._id}">${t("accept_solution_btn")}</button>` : ""}
        </div>
      </div>
    `;
  }).join("");
}

function renderComment(c) {
  return `<div class="comment-item"><div class="comment-author">${escapeHtml(c.authorName || "User")}</div><div>${escapeHtml(c.text)}</div><div style="font-size:11px;color:var(--muted);">${timeAgo(c.createdAt)}</div></div>`;
}

function attachEvents() {
  const supportBtn = document.getElementById("support-btn");
  if (supportBtn) supportBtn.addEventListener("click", async () => {
    try { await api.post(`/problems/${problemId}/support`); showToast(t("thanks_support")); load(); }
    catch (err) { showToast(err.message, "error"); }
  });

  const shareBtn = document.getElementById("share-btn");
  if (shareBtn) shareBtn.addEventListener("click", () => {
    navigator.clipboard?.writeText(window.location.href);
    showToast(t("link_copied"));
  });

  const proposeBtn = document.getElementById("propose-btn");
  if (proposeBtn) proposeBtn.addEventListener("click", () => {
    document.getElementById("propose-form-container").innerHTML = renderProposeForm();
    document.getElementById("propose-form").addEventListener("submit", submitProposal);
    document.getElementById("propose-form-container").scrollIntoView({ behavior: "smooth" });
  });

  const statusBtn = document.getElementById("update-status-btn");
  if (statusBtn) statusBtn.addEventListener("click", async () => {
    try {
      await api.patch(`/problems/${problemId}/status`, { status: document.getElementById("status-select").value, note: "Updated via web app." });
      showToast(t("status_updated_toast"));
      load();
    } catch (err) { showToast(err.message, "error"); }
  });

  document.querySelectorAll("[data-vote]").forEach((btn) => btn.addEventListener("click", async () => {
    try { await api.post(`/solutions/${btn.dataset.vote}/vote`); load(); }
    catch (err) { showToast(err.message, "error"); }
  }));

  document.querySelectorAll("[data-accept]").forEach((btn) => btn.addEventListener("click", async () => {
    try { await api.patch(`/solutions/${btn.dataset.accept}/status`, { status: "Accepted" }); showToast(t("solution_accepted_toast")); load(); }
    catch (err) { showToast(err.message, "error"); }
  }));

  document.getElementById("comment-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const text = document.getElementById("comment-text").value.trim();
    if (!text) return;
    try { await api.post(`/problems/${problemId}/comments`, { text }); load(); }
    catch (err) { showToast(err.message, "error"); }
  });
}

function renderProposeForm() {
  return `
    <div class="card" style="margin-top:14px;">
      <h4>${t("propose_form_title")}</h4>
      <form id="propose-form">
        <div class="field"><label>${t("solution_title_label")}</label><input type="text" id="sol-title" required></div>
        <div class="field"><label>${t("description_label")}</label><textarea id="sol-desc" required></textarea></div>
        <div class="form-row">
          <div class="field"><label>${t("est_cost_label")}</label><input type="number" id="sol-cost"></div>
          <div class="field"><label>${t("est_time_label")}</label><input type="text" id="sol-time" placeholder="e.g. 8 weeks"></div>
        </div>
        <div class="field"><label>${t("required_resources_label")}</label><textarea id="sol-resources"></textarea></div>
        <button class="btn btn-primary">${t("submit_proposal_btn")}</button>
      </form>
    </div>
  `;
}

async function submitProposal(e) {
  e.preventDefault();
  try {
    await api.post("/solutions", {
      problemId,
      title: document.getElementById("sol-title").value,
      description: document.getElementById("sol-desc").value,
      estimatedCost: document.getElementById("sol-cost").value,
      estimatedTime: document.getElementById("sol-time").value,
      requiredResources: document.getElementById("sol-resources").value,
    });
    showToast(t("solution_proposed_toast"));
    load();
  } catch (err) {
    showToast(err.message, "error");
  }
}

load();
