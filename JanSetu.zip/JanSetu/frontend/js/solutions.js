renderNav("solutions");
Auth.requireLogin();
applyI18n();

document.getElementById("mine-filter").innerHTML = `<option value="false">${t("all_solutions")}</option><option value="true">${t("my_solutions")}</option>`;
populateSelect(document.getElementById("status-filter"), ["Proposed", "Under Review", "Accepted", "In Progress", "Completed", "Rejected"], trStatus, { allLabel: t("all_statuses") });

async function load() {
  const resultsEl = document.getElementById("results");
  resultsEl.innerHTML = `<div class="loading-state">…</div>`;
  try {
    const query = new URLSearchParams();
    query.set("mine", document.getElementById("mine-filter").value);
    const status = document.getElementById("status-filter").value;
    if (status) query.set("status", status);

    const list = await api.get(`/solutions?${query.toString()}`);
    if (!list.length) {
      resultsEl.innerHTML = `<div class="empty-state">${t("no_solutions_found")}</div>`;
      return;
    }
    resultsEl.innerHTML = list.map((s) => `
      <a href="problem-details.html?id=${s.problemId}" class="card solution-card card-hover fade-in" style="display:block;margin-bottom:14px;">
        <div class="problem-card-top">
          <h4>${escapeHtml(s.title)}</h4>
          <span class="pill ${statusClass(s.status)}">${trStatus(s.status)}</span>
        </div>
        <p style="font-size:12.5px;color:var(--muted);margin-bottom:6px;">${escapeHtml(s.problemTitle)}</p>
        <p>${escapeHtml(s.description).slice(0, 140)}…</p>
        <div class="problem-meta">
          <span>👤 ${escapeHtml(s.proposedByName)}</span>
          <span>▲ ${s.votes || 0} ${t("vote_btn")}</span>
          ${s.estimatedCost ? `<span>💰 ₹${Number(s.estimatedCost).toLocaleString("en-IN")}</span>` : ""}
        </div>
      </a>
    `).join("");
  } catch (err) {
    resultsEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
  }
}

document.getElementById("mine-filter").addEventListener("change", load);
document.getElementById("status-filter").addEventListener("change", load);
load();
