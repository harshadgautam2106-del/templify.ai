renderNav("notifications");
Auth.requireLogin();
applyI18n();

const ICONS = {
  problem_supported: "👥", new_comment: "💬", new_solution: "💡",
  solution_accepted: "🎉", status_changed: "🔁",
};

async function load() {
  const listEl = document.getElementById("list");
  try {
    const notifications = await api.get("/notifications");
    if (!notifications.length) {
      listEl.innerHTML = `<div class="empty-state">${t("no_notifications")}</div>`;
      return;
    }
    listEl.innerHTML = notifications.map((n) => `
      <div class="card fade-in" style="margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;gap:12px;opacity:${n.read ? "0.6" : "1"};">
        <div style="display:flex;gap:10px;align-items:flex-start;">
          <span style="font-size:20px;">${ICONS[n.type] || "🔔"}</span>
          <div>
            <div>${escapeHtml(n.message)}</div>
            <div style="font-size:11.5px;color:var(--muted);margin-top:2px;">${timeAgo(n.createdAt)}</div>
          </div>
        </div>
        ${!n.read ? `<button class="btn btn-outline btn-sm" data-read="${n._id}">${t("mark_read")}</button>` : ""}
      </div>
    `).join("");

    listEl.querySelectorAll("[data-read]").forEach((btn) => btn.addEventListener("click", async () => {
      await api.patch(`/notifications/${btn.dataset.read}/read`);
      load();
      loadUnreadCount();
    }));
  } catch (err) {
    listEl.innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
  }
}

load();
