renderNav("profile");
Auth.requireLogin();

const ROLE_LABEL = { citizen: "role_citizen", student: "role_student", university: "role_university", industry: "role_industry", ngo: "role_ngo", expert: "role_expert", admin: "role_admin" };

let profile = null;

async function load() {
  try {
    profile = await api.get("/users/profile");
    render();
  } catch (err) {
    document.getElementById("content").innerHTML = `<div class="empty-state">${escapeHtml(err.message)}</div>`;
  }
}

function render() {
  document.getElementById("content").innerHTML = `
    <div class="page-header fade-in"><h1>${t("profile_title")}</h1></div>
    <div class="two-col">
      <div>
        <div class="card">
          <h3>${escapeHtml(profile.fullName)}</h3>
          <span class="role-pill">${t(ROLE_LABEL[profile.userType] || profile.userType)}</span>
          <p style="margin-top:10px;">${escapeHtml(profile.location || "—")}</p>
          <p>${escapeHtml(profile.bio || "—")}</p>
          ${profile.skills && profile.skills.length ? `<p><strong>${t("skills_label")}:</strong> ${profile.skills.map(escapeHtml).join(", ")}</p>` : ""}

          <div style="margin-top:16px;">
            ${(profile.badges || []).map((b) => `<span class="badge-earned">🏅 ${escapeHtml(b)}</span>`).join("") || `<p style="color:var(--muted);">${t("no_badges")}</p>`}
          </div>

          <div class="stats-grid" style="grid-template-columns:repeat(3,1fr);padding:20px 0 0;">
            <div class="stat-card"><div class="stat-num" id="s1">0</div><div class="stat-label">${t("stat_reported_short")}</div></div>
            <div class="stat-card"><div class="stat-num" id="s2">0</div><div class="stat-label">${t("stat_solutions_short")}</div></div>
            <div class="stat-card"><div class="stat-num" id="s3">0</div><div class="stat-label">${t("stat_supported_short")}</div></div>
          </div>
          <p style="text-align:center;margin-top:16px;"><strong>${profile.points}</strong> ${t("contribution_points")}</p>
        </div>
      </div>

      <div>
        <div class="card">
          <h4>${t("edit_profile")}</h4>
          <form id="edit-form">
            <div class="field"><label>${t("full_name")}</label><input type="text" id="fullName" value="${escapeHtml(profile.fullName)}"></div>
            <div class="field"><label>${t("location")}</label><input type="text" id="location" value="${escapeHtml(profile.location || "")}"></div>
            <div class="field"><label>${t("bio_label")}</label><textarea id="bio">${escapeHtml(profile.bio || "")}</textarea></div>
            <div class="field"><label>${t("skills_label")}</label><input type="text" id="skills" value="${(profile.skills || []).join(", ")}"></div>
            <button class="btn btn-primary btn-block">${t("save_changes")}</button>
          </form>
        </div>

        ${["university", "industry", "ngo"].includes(profile.userType) ? renderOrgCard() : ""}
      </div>
    </div>
  `;

  animateNumber(document.getElementById("s1"), profile.stats.problemsReported);
  animateNumber(document.getElementById("s2"), profile.stats.solutionsProposed);
  animateNumber(document.getElementById("s3"), profile.stats.problemsSupported);

  document.getElementById("edit-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await api.patch("/users/profile", {
        fullName: document.getElementById("fullName").value,
        location: document.getElementById("location").value,
        bio: document.getElementById("bio").value,
        skills: document.getElementById("skills").value,
      });
      showToast(t("save_changes") + " ✓");
      load();
    } catch (err) { showToast(err.message, "error"); }
  });

  const orgForm = document.getElementById("org-form");
  if (orgForm) orgForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await api.post("/users/organizations", {
        name: document.getElementById("org-name").value,
        type: profile.userType,
        location: document.getElementById("org-location").value,
        description: document.getElementById("org-desc").value,
        expertise: document.getElementById("org-expertise").value,
        contactEmail: document.getElementById("org-email").value,
      });
      showToast(t("save_org") + " ✓");
    } catch (err) { showToast(err.message, "error"); }
  });
}

function renderOrgCard() {
  return `
    <div class="card" style="margin-top:16px;">
      <h4>${t("org_profile_title")}</h4>
      <form id="org-form">
        <div class="field"><label>Organization Name</label><input type="text" id="org-name" required></div>
        <div class="field"><label>${t("location")}</label><input type="text" id="org-location"></div>
        <div class="field"><label>${t("bio_label")}</label><textarea id="org-desc"></textarea></div>
        <div class="field"><label>${t("skills_label")}</label><input type="text" id="org-expertise"></div>
        <div class="field"><label>${t("email")}</label><input type="email" id="org-email"></div>
        <button class="btn btn-outline btn-block">${t("save_org")}</button>
      </form>
    </div>
  `;
}

load();
