# JanSetu
### "Connect. Collaborate. Solve."

A civic-tech platform for crowdsourcing local community problems and connecting citizens with universities, students, industry, NGOs, and government administrators to solve them collaboratively — built exactly to the spec's requested stack: vanilla HTML/CSS/JS frontend, Node/Express backend, MongoDB/Mongoose data layer.

## 1. Read this first — what's real vs. adapted

Everything is a genuine, working full-stack app — real authentication, real data persistence, real REST APIs called from real fetch requests, not mocked UI. One thing was adapted, and your own spec explicitly allowed for it:

> *"If MongoDB is unavailable during development, create a simple development fallback/mock database layer so the application can still be demonstrated."*

This sandbox has no route to a real MongoDB server. So:
- **`backend/models/*.js`** contain real, production-correct Mongoose schemas — these would work unchanged against a real MongoDB instance.
- **`backend/utils/mockStore.js`** is the dev fallback: an in-memory store with JSON-file persistence (`backend/mockdb.json`) so data survives across restarts.
- **`backend/utils/repo.js`** is a small repository layer every controller uses. It checks whether MongoDB is actually connected (`config/database.js`) and transparently talks to the real Mongoose model or the mock store — controllers never know or care which one is active.

**To go live on real MongoDB**: set `MONGO_URI` in `backend/.env` to a real connection string (local `mongod`, Atlas, etc.) and restart. No controller code changes needed — `connectDB()` will succeed and `repo.js` automatically routes all queries to the real Mongoose models instead.

I ran the full workflow (register → report problem → support → admin verifies → student proposes solution → admin accepts → points/badges awarded → notifications fired → admin stats) as real HTTP requests against a running server during development to confirm it actually works end to end.

## 2. Project structure

Matches the spec exactly:

```
JanSetu/
├── frontend/            vanilla HTML/CSS/JS, no framework
│   ├── *.html           11 pages: index, login, register, dashboard, problems,
│   │                    problem-details, submit-problem, solutions, profile,
│   │                    notifications, admin
│   ├── css/              style.css, responsive.css, components.css
│   ├── js/               api.js, auth.js, dashboard.js, problems.js,
│   │                     problem-details.js, submit-problem.js, solutions.js,
│   │                     profile.js, notifications.js, admin.js
│   └── assets/
│
├── backend/
│   ├── server.js
│   ├── config/database.js       Mongo connection + fallback flag
│   ├── models/                  real Mongoose schemas (User, Problem, Solution,
│   │                            Comment, Notification, Organization)
│   ├── routes/                  authRoutes, problemRoutes, solutionRoutes,
│   │                            userRoutes, notificationRoutes, adminRoutes
│   ├── controllers/              matching business logic
│   ├── middleware/               authMiddleware, roleMiddleware, errorMiddleware
│   └── utils/                    helpers.js, repo.js, mockStore.js, upload.js, seed.js
│
├── .env.example
├── .gitignore
└── README.md
```

## 3. Running it locally

Requires Node.js 18+.

```bash
cd backend
npm install
npm run seed        # populates demo data (works with or without MongoDB running)
npm run dev          # starts the API on http://localhost:5000
```

In a second terminal, serve the frontend as static files (it's plain HTML/CSS/JS, any static server works):

```bash
cd frontend
python3 -m http.server 8080
# or: npx serve .
```

Open **http://localhost:8080** in your browser.

> If you do have a real MongoDB available, copy `.env.example` to `backend/.env`, set `MONGO_URI`, then run `npm run seed` and `npm run dev` again — the same seed script and server work against a real database with zero code changes.

### Demo accounts (password for all: `password123`)
```
citizen@demo.com     — Anita Verma
student@demo.com     — Ravi Kumar
university@demo.com  — MANIT Bhopal
industry@demo.com    — ABC Technologies (Fatima Sheikh)
ngo@demo.com         — Green Earth NGO
expert@demo.com      — Dr. Mehta
admin@demo.com       — District Admin
```
Plus 20 seeded problems across 5 districts, 3 organization profiles, and 5 proposed solutions.

## 4. Feature coverage against the spec

| Spec section | Status |
|---|---|
| Registration / Login / Logout, roles | ✅ real, JWT + bcrypt |
| Landing page: hero, stats, how-it-works, categories, featured problems | ✅ stats and featured problems pull live from the API |
| Citizen dashboard: overview cards, my problems, activity, quick actions | ✅ |
| Report a problem: text, category, severity, geolocation, image upload | ✅ (voice-to-text uses the browser's Web Speech API; documents beyond images and a "preview before submit" step are not built) |
| Problem discovery: search, filter, sort, support | ✅ |
| Problem details: timeline, comments, solutions, support, share | ✅ (share = copy link, no native share sheet) |
| Collaborative solutions: propose, vote, status workflow, accept | ✅ |
| Organization/university/industry/NGO profiles | ✅ basic profile + "adopt a problem"; no dedicated project tracker UI |
| Admin dashboard: stats, verify/reject, users, category chart | ✅ (chart is a CSS bar chart, not a charting library) |
| Status history / timeline | ✅ stored and rendered |
| Notifications + unread badge | ✅ |
| Global search | ✅ within Problems page; not a unified cross-entity search bar |
| Profile edit | ✅ |
| Gamification (points + badges) | ✅ simple threshold-based badges |

Not built: forgot-password email flow (UI stub only, shows an alert), a real map view (lat/long are stored and displayed as text, no map tiles), saved/bookmarked problems, comment replies/threading (schema supports `parentCommentId`, UI doesn't render nested replies yet), rate limiting and audit logging.

## 5. API reference

```
Auth
  POST   /api/auth/register
  POST   /api/auth/login
  POST   /api/auth/logout
  GET    /api/auth/me

Problems
  GET    /api/problems              ?category=&status=&severity=&district=&sort=&q=
  POST   /api/problems               (multipart form, up to 5 images)
  GET    /api/problems/:id
  POST   /api/problems/:id/support
  POST   /api/problems/:id/comments
  POST   /api/problems/comments/:commentId/like
  PATCH  /api/problems/:id/status    (admin/university/industry/ngo)
  PATCH  /api/problems/:id/assign    (admin)

Solutions
  POST   /api/solutions              (student/university/industry/ngo/expert)
  GET    /api/solutions              ?mine=true&status=
  GET    /api/solutions/problem/:problemId
  POST   /api/solutions/:id/vote
  PATCH  /api/solutions/:id/status   (admin/university/industry/ngo)

Users / Organizations
  GET    /api/users/profile
  GET    /api/users/profile/:id
  PATCH  /api/users/profile
  GET    /api/users/organizations    ?type=
  GET    /api/users/organizations/:id
  POST   /api/users/organizations
  POST   /api/users/organizations/adopt/:problemId

Notifications
  GET    /api/notifications
  GET    /api/notifications/unread-count
  PATCH  /api/notifications/:id/read

Admin (all admin-only)
  GET    /api/admin/stats
  GET    /api/admin/users
  GET    /api/admin/problems/pending
  GET    /api/admin/problems
  GET    /api/admin/solutions/review
```

All endpoints except register/login require `Authorization: Bearer <token>`.

## 6. Future scope

Real MongoDB in production (Atlas or self-hosted), a map view (Leaflet/Google Maps) using the already-stored lat/long, comment threading UI, email-based password reset, a unified global search bar across problems/solutions/organizations/users, file storage on S3 instead of local disk, and rate limiting + audit logging for the admin surface.
